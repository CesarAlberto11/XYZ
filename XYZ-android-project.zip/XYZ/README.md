# XYZ — Reproductor de música Android

App nativa (Kotlin · Jetpack Compose · Material 3 · Media3/ExoPlayer · Room · DataStore). Paquete `com.xyz.player`, minSdk 26, targetSdk 35.

## Estado honesto
- **No se compiló ni se ejecutó en el entorno de generación** (sin Android SDK, Gradle ni red). Es la primera vez que este código se compila: es probable que Android Studio muestre algunos errores menores de compilación que corregir.
- Pruebas unitarias escritas (`app/src/test`: parser LRC y motor DSP) pero **no ejecutadas**. Las fórmulas del DSP (picos del EQ, shelf de graves, RT60 de la reverb) sí se verificaron numéricamente con una réplica en Python.
- Sin probar en dispositivo: servicio en segundo plano, notificación, pantalla de bloqueo, salida USB/Bluetooth.

## Abrir y compilar
1. Android Studio Ladybug (2024.2) o superior, JDK 17.
2. `File > Open` → carpeta `XYZ`. Si pide el wrapper de Gradle, acepta (usa Gradle 8.9) o ejecuta `gradle wrapper --gradle-version 8.9`.
3. Sync, luego `Run` en un dispositivo/emulador con Android 8.0+.
4. APK de depuración: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.
5. Pruebas: `./gradlew testDebugUnitTest`.

Versiones fijadas: AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Compose BOM 2024.12.01, Media3 1.4.1 (la API `BaseAudioProcessor.onFlush()` depende de esta versión), Room 2.6.1.

## Compilar en GitHub (sin Android Studio)
1. Crea un repositorio y sube el contenido de esta carpeta (incluida `.github/`), por ejemplo: `git init && git add . && git commit -m "XYZ" && git branch -M main && git remote add origin <URL> && git push -u origin main`.
2. Pestaña **Actions** → workflow *Android build* (se ejecuta solo en cada push, o con *Run workflow*).
3. Al terminar, en el resumen del run descarga el artefacto **XYZ-debug-apk** (APK instalable, firmado con la clave debug) y **build-logs** (`build.log`, `test.log`).
4. Si falla la compilación, el error exacto está en `build.log`.

## Qué hace (implementado en código)
| Área | Implementación |
|---|---|
| Reproducción | `PlaybackService` (MediaSessionService) con ExoPlayer; segundo plano, notificación, pantalla de bloqueo, botones de auriculares, pausa al desconectar, foco de audio; cola persistida y restaurada |
| Biblioteca | MediaStore + carpetas SAF + archivos sueltos; metadatos (título, artista, álbum, género, año, pista, duración); carátulas incrustadas; duplicados por título/artista/duración; archivos ilegibles reportados; búsqueda instantánea sin acentos; favoritos, historial, más reproducidas; listas (crear, renombrar, reordenar, quitar); selección múltiple |
| Letras | LRC (varias marcas por línea, `[offset]`, marcas por palabra ignoradas), letra incrustada leída directamente del archivo (MP3: ID3 USLT/SYLT/TXXX; M4A: átomo ©lyr; FLAC: comentario Vorbis; otros formatos vía metadatos de ExoPlayer), importación manual; línea actual nítida, vecinas con menos opacidad y desenfoque progresivo (desenfoque real en Android 12+), autoscroll, toque para saltar, tamaño y desfase ajustables |
| Audio | Motor DSP propio en el pipeline de ExoPlayer: EQ de 10 bandas + preamp, 12 presets, perfiles propios, bass boost, reverb (RT60 real), 3 salas, realce estéreo, ancho, balance, ReplayGain, limitador de picos, visualizador FFT real, medidor de pico |
| Velocidad | 0,5×–2,0× con y sin tono vinculado, modo Slowed; aplicada al audio (Sonic de ExoPlayer) |
| Salida | Dispositivo activo (Android 13+), lista de salidas, "preferir dispositivo", acceso al selector del sistema, datos del archivo vs. mezclador |
| UI | Estética clara con curvas (fondo con ondas bezier, paneles y barra inferior redondeados, botones circulares BASS/HALL/SPATIAL, perilla de preamp, sliders con pulgar redondo); temas claro (predeterminado)/oscuro/auto, 17 colores de acento + color personalizado por tono, tablets (riel de navegación y reproductor de dos paneles), reducción de movimiento, descripciones para lectores de pantalla |
| Idiomas | Español e inglés completos (`values/` y `values-es/`), cambio en la app persistente |

## Limitaciones declaradas en la app
- El audio espacial es un **realce estéreo**, no Dolby Atmos ni audio espacial del sistema.
- El "crossfade" es un **fundido secuencial** (baja y sube), no solapa canciones.
- Editar metadatos modifica **solo la biblioteca de XYZ**, no los archivos.
- No se afirma bit-perfect ni alta resolución: el mezclador de Android decide la salida final.
- La cola enviada al reproductor se limita a 1000 canciones por reproducción.
- Letras junto al archivo (`.lrc` hermano) se detectan en carpetas SAF; en MediaStore solo si Android permite leer el archivo. Si no, se usa "Importar LRC".
- La carátula de la notificación sale de la portada incrustada.
- La cola se reordena con botones subir/bajar (no arrastrar).

## Estructura
```
app/src/main/java/com/xyz/player/
  audio/     DspCore (EQ, reverb, limitador, FFT), XyzDspProcessor (AudioProcessor), AudioEngine, presets
  data/      Room (canciones, listas), Prefs (DataStore), Library (escaneo), ArtLoader
  lyrics/    parser LRC y almacén
  playback/  PlaybackService, ArtBitmapLoader
  ui/        tema, navegación, pantallas, MainViewModel
```
