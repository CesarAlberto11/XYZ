# Room / Media3 ship consumer rules. Add project-specific rules here if minification is enabled.
