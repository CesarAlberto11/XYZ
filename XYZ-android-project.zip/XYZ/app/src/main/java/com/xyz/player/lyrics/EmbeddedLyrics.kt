package com.xyz.player.lyrics

import android.content.Context
import android.net.Uri
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.Charset

/**
 * Reads lyrics stored inside the audio file itself, independent of the player:
 *  - MP3: ID3v2 USLT (plain/LRC text), SYLT (synced, millisecond timestamps) and TXXX LYRICS
 *  - M4A/MP4: iTunes "©lyr" atom
 *  - FLAC: Vorbis comment LYRICS / UNSYNCEDLYRICS / SYNCEDLYRICS
 * Returns LRC-compatible text (SYLT is converted to [mm:ss.xx] lines) or null when the file has no lyrics.
 */
object EmbeddedLyrics {
    private const val MAX_BLOCK = 24 * 1024 * 1024
    private val LATIN1: Charset = Charsets.ISO_8859_1

    fun read(ctx: Context, uri: String): String? = try {
        ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")?.use { pfd ->
            FileInputStream(pfd.fileDescriptor).use { fis ->
                val ch = fis.channel
                val head = readFully(ch, 0, 12) ?: return@use null
                when {
                    head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte() -> readId3(ch, head)
                    String(head, 0, 4, LATIN1) == "fLaC" -> readFlac(ch)
                    String(head, 4, 4, LATIN1) == "ftyp" -> readMp4(ch)
                    else -> null
                }
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun readFully(ch: FileChannel, pos: Long, len: Int): ByteArray? {
        if (len < 0 || pos < 0 || pos + len > ch.size()) return null
        val buf = ByteBuffer.allocate(len)
        var p = pos
        while (buf.hasRemaining()) {
            val n = ch.read(buf, p)
            if (n <= 0) return null
            p += n
        }
        return buf.array()
    }

    // ------------------------------------------------------------------ byte helpers
    private fun u(b: ByteArray, i: Int) = b[i].toInt() and 0xFF
    private fun be32(b: ByteArray, i: Int): Long =
        ((u(b, i).toLong() shl 24) or (u(b, i + 1).toLong() shl 16) or (u(b, i + 2).toLong() shl 8) or u(b, i + 3).toLong())
    private fun be24(b: ByteArray, i: Int): Int = (u(b, i) shl 16) or (u(b, i + 1) shl 8) or u(b, i + 2)
    private fun syncsafe(b: ByteArray, i: Int): Int =
        ((u(b, i) and 0x7F) shl 21) or ((u(b, i + 1) and 0x7F) shl 14) or ((u(b, i + 2) and 0x7F) shl 7) or (u(b, i + 3) and 0x7F)
    private fun le32(b: ByteArray, i: Int): Int =
        u(b, i) or (u(b, i + 1) shl 8) or (u(b, i + 2) shl 16) or (u(b, i + 3) shl 24)

    // ------------------------------------------------------------------ ID3v2 (MP3)
    private fun readId3(ch: FileChannel, head: ByteArray): String? {
        val h = head.copyOf(10)
        val size = syncsafe(h, 6)
        if (size <= 0 || size > MAX_BLOCK) return null
        val body = readFully(ch, 10, minOf(size.toLong(), ch.size() - 10).toInt()) ?: return null
        return parseId3(h, body)
    }

    /** [header] = first 10 bytes of the tag, [body] = the tag content without header. */
    fun parseId3(header: ByteArray, body: ByteArray): String? {
        val major = u(header, 3)
        if (major !in 2..4) return null
        val flags = u(header, 5)
        val b = if ((flags and 0x80) != 0 && major < 4) unsync(body) else body
        var p = 0
        if ((flags and 0x40) != 0 && major >= 3 && b.size >= 4) {
            p = if (major == 3) 4 + be32(b, 0).toInt() else syncsafe(b, 0)
        }
        val idLen = if (major == 2) 3 else 4
        val hdr = if (major == 2) 6 else 10
        var uslt: String? = null
        var sylt: String? = null
        var txxx: String? = null
        while (p + hdr <= b.size) {
            if (b[p].toInt() == 0) break
            val id = String(b, p, idLen, LATIN1)
            val fsz = when (major) { 2 -> be24(b, p + 3); 3 -> be32(b, p + 4).toInt(); else -> syncsafe(b, p + 4) }
            var ds = p + hdr
            val de = ds + fsz
            if (fsz <= 0 || de > b.size) break
            if (major == 4 && (u(b, p + 9) and 0x01) != 0) ds += 4 // data length indicator
            if (ds < de) when (id) {
                "USLT", "ULT" -> if (uslt == null) uslt = parseUslt(b, ds, de)
                "SYLT", "SLT" -> if (sylt == null) sylt = parseSylt(b, ds, de)
                "TXXX", "TXX" -> if (txxx == null) txxx = parseTxxx(b, ds, de)
            }
            p = de
        }
        return sylt ?: uslt ?: txxx
    }

    private fun unsync(b: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream(b.size)
        var i = 0
        while (i < b.size) {
            out.write(b[i].toInt())
            if (b[i] == 0xFF.toByte() && i + 1 < b.size && b[i + 1].toInt() == 0) i++
            i++
        }
        return out.toByteArray()
    }

    private fun charsetFor(enc: Int, b: ByteArray, s: Int, e: Int): Pair<Charset, Int> = when (enc) {
        0 -> LATIN1 to s
        1 -> if (e - s >= 2 && u(b, s) == 0xFF && u(b, s + 1) == 0xFE) Charsets.UTF_16LE to s + 2
        else if (e - s >= 2 && u(b, s) == 0xFE && u(b, s + 1) == 0xFF) Charsets.UTF_16BE to s + 2
        else Charsets.UTF_16LE to s
        2 -> Charsets.UTF_16BE to s
        else -> Charsets.UTF_8 to s
    }

    private fun decode(b: ByteArray, s: Int, e: Int, enc: Int): String {
        if (e <= s) return ""
        val (cs, start) = charsetFor(enc, b, s, e)
        return String(b, start, (e - start).coerceAtLeast(0), cs)
    }

    /** Index of the first string terminator at/after [from], or -1. */
    private fun term(b: ByteArray, from: Int, to: Int, enc: Int): Int {
        if (enc == 1 || enc == 2) {
            var i = from
            while (i + 1 < to) { if (b[i].toInt() == 0 && b[i + 1].toInt() == 0) return i; i += 2 }
            return -1
        }
        for (i in from until to) if (b[i].toInt() == 0) return i
        return -1
    }

    private fun tl(enc: Int) = if (enc == 1 || enc == 2) 2 else 1

    private fun parseUslt(b: ByteArray, s: Int, e: Int): String? {
        if (e - s < 5) return null
        val enc = u(b, s)
        val t = term(b, s + 4, e, enc)
        val textStart = if (t < 0) s + 4 else t + tl(enc)
        return decode(b, textStart, e, enc).trim().ifBlank { null }
    }

    private fun parseSylt(b: ByteArray, s: Int, e: Int): String? {
        if (e - s < 7) return null
        val enc = u(b, s)
        val format = u(b, s + 4)
        if (format != 2) return null // only millisecond timestamps can be converted reliably
        val t0 = term(b, s + 6, e, enc)
        var p = if (t0 < 0) return null else t0 + tl(enc)
        val sb = StringBuilder()
        while (p < e) {
            val t = term(b, p, e, enc)
            if (t < 0) break
            val text = decode(b, p, t, enc).trim()
            p = t + tl(enc)
            if (p + 4 > e) break
            val ms = be32(b, p)
            p += 4
            sb.append('[').append("%02d:%02d.%02d".format(ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10)).append(']').append(text).append('\n')
        }
        return sb.toString().trim().ifBlank { null }
    }

    private fun parseTxxx(b: ByteArray, s: Int, e: Int): String? {
        if (e - s < 2) return null
        val enc = u(b, s)
        val t = term(b, s + 1, e, enc)
        if (t < 0) return null
        val desc = decode(b, s + 1, t, enc).trim()
        if (!desc.equals("LYRICS", true) && !desc.equals("UNSYNCEDLYRICS", true) && !desc.equals("USLT", true)) return null
        return decode(b, t + tl(enc), e, enc).trim().ifBlank { null }
    }

    // ------------------------------------------------------------------ MP4 / M4A
    private fun readMp4(ch: FileChannel): String? {
        var pos = 0L
        val size = ch.size()
        while (pos + 8 <= size) {
            val h = readFully(ch, pos, 8) ?: return null
            var sz = be32(h, 0)
            val type = String(h, 4, 4, LATIN1)
            var hl = 8
            if (sz == 1L) {
                val ext = readFully(ch, pos + 8, 8) ?: return null
                sz = (be32(ext, 0) shl 32) or be32(ext, 4)
                hl = 16
            } else if (sz == 0L) sz = size - pos
            if (sz < hl) return null
            if (type == "moov") {
                val len = sz - hl
                if (len > MAX_BLOCK) return null
                val buf = readFully(ch, pos + hl, len.toInt()) ?: return null
                return parseMp4Moov(buf)
            }
            pos += sz
        }
        return null
    }

    /** [moov] = content of the moov box (without its 8-byte header). */
    fun parseMp4Moov(moov: ByteArray): String? = walkMp4(moov, 0, moov.size, listOf("udta", "meta", "ilst"))

    private fun walkMp4(b: ByteArray, s: Int, e: Int, path: List<String>): String? {
        var p = s
        while (p + 8 <= e) {
            val sz = be32(b, p)
            if (sz < 8 || p + sz > e) return null
            val end = (p + sz).toInt()
            val type = String(b, p + 4, 4, LATIN1)
            if (path.isNotEmpty()) {
                if (type == path[0]) {
                    val cs = if (type == "meta") p + 12 else p + 8 // "meta" is a full box (version+flags)
                    walkMp4(b, cs, end, path.drop(1))?.let { return it }
                }
            } else if (type == "\u00A9lyr") {
                var q = p + 8
                while (q + 8 <= end) {
                    val dsz = be32(b, q).toInt()
                    if (dsz < 16 || q + dsz > end) break
                    if (String(b, q + 4, 4, LATIN1) == "data") {
                        return String(b, q + 16, dsz - 16, Charsets.UTF_8).trim().ifBlank { null }
                    }
                    q += dsz
                }
            }
            p = end
        }
        return null
    }

    // ------------------------------------------------------------------ FLAC
    private fun readFlac(ch: FileChannel): String? {
        var pos = 4L
        val size = ch.size()
        while (pos + 4 <= size) {
            val h = readFully(ch, pos, 4) ?: return null
            val last = (u(h, 0) and 0x80) != 0
            val type = u(h, 0) and 0x7F
            val len = be24(h, 1)
            if (type == 4) {
                if (len > MAX_BLOCK) return null
                return parseVorbisComments(readFully(ch, pos + 4, len) ?: return null)
            }
            if (last) break
            pos += 4L + len
        }
        return null
    }

    fun parseVorbisComments(b: ByteArray): String? {
        if (b.size < 8) return null
        var p = 4 + le32(b, 0)
        if (p < 0 || p + 4 > b.size) return null
        val n = le32(b, p)
        p += 4
        repeat(n.coerceIn(0, 10_000)) {
            if (p + 4 > b.size) return null
            val l = le32(b, p)
            p += 4
            if (l < 0 || p + l > b.size) return null
            val s = String(b, p, l, Charsets.UTF_8)
            p += l
            val i = s.indexOf('=')
            if (i > 0) {
                val key = s.substring(0, i).uppercase()
                if (key == "LYRICS" || key == "UNSYNCEDLYRICS" || key == "SYNCEDLYRICS") return s.substring(i + 1).trim().ifBlank { null }
            }
        }
        return null
    }
}
