package com.xyz.player.lyrics

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Stores imported / discovered .lrc text in app-private storage, keyed by song URI. */
class LyricsStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun file(uri: String): File {
        val h = MessageDigest.getInstance("SHA-1").digest(uri.toByteArray()).joinToString("") { "%02x".format(it) }
        return File(dir, "$h.lrc")
    }

    fun has(uri: String) = file(uri).exists()
    fun load(uri: String): String? = file(uri).takeIf { it.exists() }?.let { runCatching { it.readText() }.getOrNull() }
    fun save(uri: String, text: String) { runCatching { file(uri).writeText(text.take(1_000_000)) } }
    fun delete(uri: String) { runCatching { file(uri).delete() } }
}
