package com.xyz.player.data

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.xyz.player.lyrics.LyricsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import java.io.File

class LibraryRepository(
    private val ctx: Context,
    db: XyzDb,
    private val prefs: Prefs,
    private val lyrics: LyricsStore,
) {
    private val songDao = db.songs()
    private val plDao = db.playlists()

    val songs: Flow<List<SongEntity>> = songDao.observeAll()
    val playlists: Flow<List<PlaylistEntity>> = plDao.observePlaylists()
    val entries: Flow<List<PlaylistEntry>> = plDao.observeEntries()
    val scan = MutableStateFlow(ScanProgress())
    private val scanLock = Mutex()

    private val audioExt = setOf("mp3", "flac", "wav", "aac", "m4a", "ogg", "oga", "opus", "mka", "3gp", "amr")

    fun hasAudioPermission(): Boolean = ContextCompat.checkSelfPermission(
        ctx,
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE,
    ) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- scanning

    suspend fun scanAll(treeUris: Set<String>) = withContext(Dispatchers.IO) {
        if (!scanLock.tryLock()) return@withContext
        try {
            scan.value = ScanProgress(running = true)
            val existing = songDao.getAll().associateBy { it.uri }
            val found = ArrayList<SongEntity>()
            val skippedNames = ArrayList<String>()
            var skipped = 0
            fun push() {
                scan.value = scan.value.copy(found = found.size, skipped = skipped, skippedNames = skippedNames.take(30))
            }
            val onFound: (SongEntity) -> Unit = { found += it; if (found.size % 25 == 0) push() }
            val onSkip: (String) -> Unit = { skipped++; skippedNames += it; push() }

            val perm = hasAudioPermission()
            if (perm) queryMediaStore(onFound, onSkip)
            for (t in treeUris) {
                val root = runCatching { DocumentFile.fromTreeUri(ctx, Uri.parse(t)) }.getOrNull() ?: continue
                walk(root, root.name ?: "", onFound, onSkip)
            }
            push()

            // merge: preserve user data, detect duplicates
            val seen = HashMap<String, String>()
            val keep = ArrayList<SongEntity>(found.size)
            var dups = 0
            for (s in found) {
                val prior = seen[s.dedupKey]
                if (prior != null && prior != s.uri) { dups++; continue }
                seen[s.dedupKey] = s.uri
                val old = existing[s.uri]
                keep += if (old == null) s else {
                    val m = s.copy(favorite = old.favorite, playCount = old.playCount, lastPlayed = old.lastPlayed)
                    if (old.edited) m.copy(title = old.title, artist = old.artist, album = old.album, edited = true) else m
                }
            }
            keep.chunked(400).forEach { songDao.upsertAll(it) }

            val keepUris = keep.mapTo(HashSet()) { it.uri }
            val scanned = buildSet {
                if (perm) add(0)
                if (treeUris.isNotEmpty()) add(1)
            }
            val stale = existing.values.filter { it.source in scanned && it.uri !in keepUris }.map { it.uri }
            stale.chunked(400).forEach { songDao.deleteByUris(it) }

            scan.value = scan.value.copy(
                running = false, done = true, found = keep.size, duplicates = dups, removed = stale.size,
                noPermission = !perm && treeUris.isEmpty(),
            )
        } catch (e: Exception) {
            scan.value = scan.value.copy(running = false, done = true)
        } finally {
            scanLock.unlock()
        }
        Unit
    }

    private fun queryMediaStore(onFound: (SongEntity) -> Unit, onSkip: (String) -> Unit) {
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val cols = mutableListOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DATA,
        )
        val hasGenre = Build.VERSION.SDK_INT >= 30
        if (hasGenre) cols += MediaStore.Audio.AudioColumns.GENRE
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 15000"
        ctx.contentResolver.query(collection, cols.toTypedArray(), sel, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iGenre = if (hasGenre) c.getColumnIndex(MediaStore.Audio.AudioColumns.GENRE) else -1
            while (c.moveToNext()) {
                try {
                    val uri = ContentUris.withAppendedId(collection, c.getLong(iId)).toString()
                    val name = c.getString(iName).orEmpty()
                    val data = c.getString(iData).orEmpty()
                    val song = makeSong(
                        uri = uri,
                        title = c.getString(iTitle).clean().ifBlank { name.substringBeforeLast('.') },
                        artist = c.getString(iArtist).clean(),
                        album = c.getString(iAlbum).clean(),
                        genre = if (iGenre >= 0) c.getString(iGenre).clean() else "",
                        year = c.getInt(iYear),
                        track = c.getInt(iTrack) % 1000,
                        durationMs = c.getLong(iDur),
                        folder = File(data).parent.orEmpty(),
                        mime = c.getString(iMime).orEmpty(),
                        added = c.getLong(iAdded),
                        source = 0,
                    )
                    onFound(song)
                    if (!lyrics.has(uri) && data.isNotEmpty()) {
                        val lrc = File(data.substringBeforeLast('.') + ".lrc")
                        runCatching { if (lrc.canRead() && lrc.length() < 1_000_000) lyrics.save(uri, lrc.readText()) }
                    }
                } catch (e: Exception) {
                    onSkip(c.getString(iName).orEmpty())
                }
            }
        }
    }

    private fun walk(dir: DocumentFile, path: String, onFound: (SongEntity) -> Unit, onSkip: (String) -> Unit) {
        val children = try { dir.listFiles() } catch (e: Exception) { return }
        val lrcByBase = children.filter { it.isFile && it.name?.endsWith(".lrc", true) == true }
            .associateBy { it.name!!.substringBeforeLast('.').lowercase() }
        for (f in children) {
            val name = f.name ?: continue
            if (f.isDirectory) { walk(f, "$path/$name", onFound, onSkip); continue }
            val ext = name.substringAfterLast('.', "").lowercase()
            if (f.type?.startsWith("audio/") != true && ext !in audioExt) continue
            val song = readDocument(f.uri, name, path, 1, f.type, f.lastModified() / 1000)
            if (song == null) { onSkip(name); continue }
            onFound(song)
            val base = name.substringBeforeLast('.').lowercase()
            lrcByBase[base]?.let { l ->
                if (!lyrics.has(song.uri)) importLrc(l.uri, song.uri)
            }
        }
    }

    private fun importLrc(lrcUri: Uri, songUri: String) {
        runCatching {
            ctx.contentResolver.openInputStream(lrcUri)?.use { ins ->
                lyrics.save(songUri, ins.bufferedReader().readText())
            }
        }
    }

    private fun readDocument(uri: Uri, name: String, folder: String, source: Int, mimeHint: String?, added: Long): SongEntity? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            if (dur <= 0) return null
            fun md(k: Int) = r.extractMetadata(k).clean()
            makeSong(
                uri = uri.toString(),
                title = md(MediaMetadataRetriever.METADATA_KEY_TITLE).ifBlank { name.substringBeforeLast('.') },
                artist = md(MediaMetadataRetriever.METADATA_KEY_ARTIST).ifBlank { md(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST) },
                album = md(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                genre = md(MediaMetadataRetriever.METADATA_KEY_GENRE),
                year = md(MediaMetadataRetriever.METADATA_KEY_YEAR).take(4).toIntOrNull() ?: 0,
                track = md(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER).substringBefore('/').toIntOrNull() ?: 0,
                durationMs = dur,
                folder = folder,
                mime = md(MediaMetadataRetriever.METADATA_KEY_MIMETYPE).ifBlank { mimeHint.orEmpty() },
                added = added,
                source = source,
            )
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    suspend fun importFiles(uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var n = 0
        val list = ArrayList<SongEntity>()
        for (u in uris) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = DocumentFile.fromSingleUri(ctx, u)?.name ?: u.lastPathSegment.orEmpty()
            val s = readDocument(u, name, "", 2, null, System.currentTimeMillis() / 1000)
            if (s != null) { list += s; n++ }
        }
        list.chunked(400).forEach { songDao.upsertAll(it) }
        n
    }

    private fun String?.clean(): String {
        val s = this?.trim().orEmpty()
        return if (s == MediaStore.UNKNOWN_STRING || s.equals("<unknown>", true)) "" else s
    }

    private fun makeSong(
        uri: String, title: String, artist: String, album: String, genre: String, year: Int, track: Int,
        durationMs: Long, folder: String, mime: String, added: Long, source: Int,
    ) = SongEntity(
        uri = uri, title = title, artist = artist, album = album, genre = genre, year = year, trackNo = track,
        durationMs = durationMs, folder = folder, mime = mime, dateAdded = added, source = source,
        dedupKey = "${normalize(title)}|${normalize(artist)}|${durationMs / 2000}",
    )

    // ---------------------------------------------------------------- songs

    suspend fun songsByUris(uris: List<String>): Map<String, SongEntity> = withContext(Dispatchers.IO) {
        uris.distinct().chunked(400).flatMap { songDao.getByUris(it) }.associateBy { it.uri }
    }
    suspend fun setFavorite(uris: List<String>, fav: Boolean) = uris.chunked(400).forEach { songDao.setFavorite(it, fav) }
    suspend fun markPlayed(uri: String) = songDao.markPlayed(uri, System.currentTimeMillis())
    suspend fun editMeta(uri: String, title: String, artist: String, album: String) = songDao.editMeta(uri, title, artist, album)

    // ---------------------------------------------------------------- playlists

    suspend fun createPlaylist(name: String, uris: List<String>): Long {
        val id = plDao.insertPlaylist(PlaylistEntity(name = name))
        if (uris.isNotEmpty()) plDao.appendEntries(id, uris)
        return id
    }
    suspend fun renamePlaylist(id: Long, name: String) = plDao.rename(id, name)
    suspend fun deletePlaylist(id: Long) = plDao.removePlaylist(id)
    suspend fun addToPlaylist(id: Long, uris: List<String>) = plDao.appendEntries(id, uris)
    suspend fun setPlaylistOrder(id: Long, uris: List<String>) = plDao.replaceEntries(id, uris)
}
