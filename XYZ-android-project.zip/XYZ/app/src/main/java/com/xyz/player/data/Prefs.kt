package com.xyz.player.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.xyz.player.audio.DspSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.xyzStore: DataStore<Preferences> by preferencesDataStore(name = "xyz_prefs")

data class AppSettings(
    val themeMode: Int = 0, // 0 system, 1 light, 2 dark
    val accent: Int = 0,
    val grid: Boolean = false,
    val lyricsSize: Int = 26,
    val lyricsOffsetMs: Int = 0,
    val speed: Float = 1f,
    val pitchLinked: Boolean = false,
    val crossfadeMs: Int = 0,
    val reduceMotion: Boolean = false,
    val folders: Set<String> = emptySet(),
)

data class EqProfile(val name: String, val preampDb: Float, val bands: List<Float>)
data class SavedSession(val uris: List<String>, val index: Int, val positionMs: Long, val shuffle: Boolean, val repeat: Int)

class Prefs(private val ctx: Context) {
    private object K {
        val THEME = intPreferencesKey("theme")
        val ACCENT = intPreferencesKey("accent")
        val GRID = booleanPreferencesKey("grid")
        val LYR_SIZE = intPreferencesKey("lyrics_size")
        val LYR_OFFSET = intPreferencesKey("lyrics_offset")
        val SPEED = floatPreferencesKey("speed")
        val PITCH_LINKED = booleanPreferencesKey("pitch_linked")
        val CROSSFADE = intPreferencesKey("crossfade")
        val REDUCE = booleanPreferencesKey("reduce_motion")
        val FOLDERS = stringSetPreferencesKey("folders")
        val DSP = stringPreferencesKey("dsp")
        val EQ_PROFILES = stringPreferencesKey("eq_profiles")
        val Q_URIS = stringPreferencesKey("q_uris")
        val Q_INDEX = intPreferencesKey("q_index")
        val Q_POS = longPreferencesKey("q_pos")
        val Q_SHUFFLE = booleanPreferencesKey("q_shuffle")
        val Q_REPEAT = intPreferencesKey("q_repeat")
    }

    val settings: Flow<AppSettings> = ctx.xyzStore.data.map { p ->
        AppSettings(
            themeMode = p[K.THEME] ?: 0,
            accent = p[K.ACCENT] ?: 0,
            grid = p[K.GRID] ?: false,
            lyricsSize = p[K.LYR_SIZE] ?: 26,
            lyricsOffsetMs = p[K.LYR_OFFSET] ?: 0,
            speed = p[K.SPEED] ?: 1f,
            pitchLinked = p[K.PITCH_LINKED] ?: false,
            crossfadeMs = p[K.CROSSFADE] ?: 0,
            reduceMotion = p[K.REDUCE] ?: false,
            folders = p[K.FOLDERS] ?: emptySet(),
        )
    }

    private suspend fun <T> put(k: Preferences.Key<T>, v: T) { ctx.xyzStore.edit { it[k] = v } }

    suspend fun setTheme(v: Int) = put(K.THEME, v)
    suspend fun setAccent(v: Int) = put(K.ACCENT, v)
    suspend fun setGrid(v: Boolean) = put(K.GRID, v)
    suspend fun setLyricsSize(v: Int) = put(K.LYR_SIZE, v)
    suspend fun setLyricsOffset(v: Int) = put(K.LYR_OFFSET, v)
    suspend fun setCrossfade(v: Int) = put(K.CROSSFADE, v)
    suspend fun setReduceMotion(v: Boolean) = put(K.REDUCE, v)
    suspend fun setSpeed(speed: Float, linked: Boolean) {
        ctx.xyzStore.edit { it[K.SPEED] = speed; it[K.PITCH_LINKED] = linked }
    }
    suspend fun addFolder(uri: String) { ctx.xyzStore.edit { it[K.FOLDERS] = (it[K.FOLDERS] ?: emptySet()) + uri } }
    suspend fun removeFolder(uri: String) { ctx.xyzStore.edit { it[K.FOLDERS] = (it[K.FOLDERS] ?: emptySet()) - uri } }

    // ---- DSP ----
    suspend fun saveDsp(s: DspSettings) = put(K.DSP, s.toJson())
    suspend fun loadDsp(): DspSettings =
        ctx.xyzStore.data.first()[K.DSP]?.let { runCatching { DspSettings.fromJson(it) }.getOrNull() } ?: DspSettings()

    // ---- custom EQ profiles ----
    val eqProfiles: Flow<List<EqProfile>> = ctx.xyzStore.data.map { p ->
        runCatching {
            val arr = JSONArray(p[K.EQ_PROFILES] ?: "[]")
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val b = o.getJSONArray("bands")
                EqProfile(o.getString("name"), o.optDouble("pre", 0.0).toFloat(), List(b.length()) { j -> b.getDouble(j).toFloat() })
            }
        }.getOrDefault(emptyList())
    }

    suspend fun saveEqProfiles(list: List<EqProfile>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().put("name", e.name).put("pre", e.preampDb.toDouble())
                .put("bands", JSONArray().also { a -> e.bands.forEach { v -> a.put(v.toDouble()) } }))
        }
        put(K.EQ_PROFILES, arr.toString())
    }

    // ---- playback session ----
    suspend fun saveSession(uris: List<String>, index: Int, pos: Long, shuffle: Boolean, repeat: Int) {
        ctx.xyzStore.edit {
            it[K.Q_URIS] = uris.joinToString("\n")
            it[K.Q_INDEX] = index
            it[K.Q_POS] = pos
            it[K.Q_SHUFFLE] = shuffle
            it[K.Q_REPEAT] = repeat
        }
    }

    suspend fun loadSession(): SavedSession? {
        val p = ctx.xyzStore.data.first()
        val raw = p[K.Q_URIS] ?: return null
        val uris = raw.split('\n').filter { it.isNotBlank() }
        if (uris.isEmpty()) return null
        return SavedSession(uris, p[K.Q_INDEX] ?: 0, p[K.Q_POS] ?: 0L, p[K.Q_SHUFFLE] ?: false, p[K.Q_REPEAT] ?: 0)
    }
}
