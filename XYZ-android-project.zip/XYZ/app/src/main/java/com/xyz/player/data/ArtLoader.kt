package com.xyz.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors

/** Loads embedded cover art (or the MediaStore thumbnail) with a small in-memory cache. */
object ArtLoader {
    val dispatcher = Executors.newFixedThreadPool(3).asCoroutineDispatcher()

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val misses = HashSet<String>()

    fun peek(uri: String, size: Int): Bitmap? = cache.get("$uri@$size")

    fun load(ctx: Context, uri: String, size: Int): Bitmap? {
        val key = "$uri@$size"
        cache.get(key)?.let { return it }
        synchronized(misses) { if (key in misses) return null }
        var bmp: Bitmap? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(uri))
            r.embeddedPicture?.let { bmp = decodeSampled(it, size) }
        } catch (_: Exception) {
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
        if (bmp == null && Build.VERSION.SDK_INT >= 29 && uri.startsWith("content://media")) {
            try { bmp = ctx.contentResolver.loadThumbnail(Uri.parse(uri), Size(size, size), null) } catch (_: Exception) {}
        }
        val result = bmp
        if (result != null) cache.put(key, result) else synchronized(misses) { misses.add(key) }
        return result
    }

    private fun decodeSampled(bytes: ByteArray, target: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= target && o.outHeight / (sample * 2) >= target) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}
