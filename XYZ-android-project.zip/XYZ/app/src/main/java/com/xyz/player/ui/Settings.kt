package com.xyz.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.xyz.player.R

@Composable
private fun Group(titleRes: Int, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(titleRes), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(titleRes: Int, descRes: Int?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(titleRes), fontWeight = FontWeight.Medium)
            if (descRes != null) Text(stringResource(descRes), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scan by vm.scan.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    var lang by remember { mutableStateOf(AppCompatDelegate.getApplicationLocales().toLanguageTags().take(2)) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) vm.addFolder(u) }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l -> if (l.isNotEmpty()) vm.addFiles(l) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty() }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_settings))
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Group(R.string.appearance) {
                Text(stringResource(R.string.theme), fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.theme_auto, R.string.theme_light, R.string.theme_dark).forEachIndexed { i, r ->
                        FilterChip(selected = settings.themeMode == i, onClick = { vm.setTheme(i) }, label = { Text(stringResource(r)) })
                    }
                }
                Text(stringResource(R.string.accent_color), fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Accents.forEachIndexed { i, a ->
                        val name = stringResource(a.nameRes)
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(a.color)
                                .selectable(selected = settings.accent == i, role = Role.RadioButton, onClick = { vm.setAccent(i) })
                                .semantics { contentDescription = name },
                            contentAlignment = Alignment.Center,
                        ) { if (settings.accent == i) Icon(Icons.Rounded.Check, null, tint = androidx.compose.ui.graphics.Color.White) }
                    }
                }
                SwitchRow(R.string.grid_default, R.string.grid_default_desc, settings.grid) { vm.setGrid(it) }
                SwitchRow(R.string.reduce_motion, R.string.reduce_motion_desc, settings.reduceMotion) { vm.setReduceMotion(it) }
            }

            Group(R.string.language) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("" to R.string.lang_system, "es" to R.string.lang_es, "en" to R.string.lang_en).forEach { (tag, r) ->
                        FilterChip(selected = lang == tag, onClick = {
                            lang = tag
                            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
                        }, label = { Text(stringResource(r)) })
                    }
                }
            }

            Group(R.string.library) {
                Text(stringResource(R.string.n_songs, songs.size), style = MaterialTheme.typography.bodyMedium)
                if (scan.running) {
                    Text(stringResource(R.string.scanning_found, scan.found))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                } else if (scan.done) {
                    Text(stringResource(R.string.scan_summary, scan.found, scan.duplicates, scan.skipped, scan.removed), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (scan.noPermission) Text(stringResource(R.string.perm_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    if (scan.skippedNames.isNotEmpty()) {
                        Text(stringResource(R.string.skipped_files), style = MaterialTheme.typography.labelLarge)
                        Text(scan.skippedNames.joinToString("\n"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Button(onClick = { vm.startScan() }, enabled = !scan.running, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Refresh, null); Text(stringResource(R.string.scan_now), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.FolderOpen, null); Text(stringResource(R.string.add_folder), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = { filePicker.launch(arrayOf("audio/*", "application/ogg", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.UploadFile, null); Text(stringResource(R.string.add_files), modifier = Modifier.padding(start = 8.dp))
                }
                if (settings.folders.isNotEmpty()) {
                    Text(stringResource(R.string.authorized_folders), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 4.dp))
                    settings.folders.forEach { f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(android.net.Uri.decode(f).substringAfterLast(':').ifBlank { f }, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            IconButton(onClick = { vm.removeFolder(f) }) { Icon(Icons.Rounded.Close, stringResource(R.string.remove_folder)) }
                        }
                    }
                }
            }

            Group(R.string.audio) {
                OutlinedButton(onClick = { nav.navigate(Routes.OUTPUT) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Headphones, null); Text(stringResource(R.string.output), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = { nav.navigateTab(Routes.EFFECTS) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.nav_effects)) }
            }

            Group(R.string.about) {
                Text("XYZ  $version", fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.about_limits), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
