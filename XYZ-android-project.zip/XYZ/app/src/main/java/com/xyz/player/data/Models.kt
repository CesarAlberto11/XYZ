package com.xyz.player.data

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import java.text.Normalizer

data class AlbumItem(val name: String, val artist: String, val various: Boolean, val songs: List<SongEntity>)
data class ArtistItem(val name: String, val songs: List<SongEntity>, val albumCount: Int)
data class FolderItem(val path: String, val name: String, val songs: List<SongEntity>)
data class PlaylistUi(val id: Long, val name: String, val songs: List<SongEntity>)
data class SearchResults(
    val songs: List<SongEntity> = emptyList(),
    val albums: List<AlbumItem> = emptyList(),
    val artists: List<ArtistItem> = emptyList(),
) {
    val isEmpty get() = songs.isEmpty() && albums.isEmpty() && artists.isEmpty()
}

data class ScanProgress(
    val running: Boolean = false,
    val done: Boolean = false,
    val found: Int = 0,
    val skipped: Int = 0,
    val duplicates: Int = 0,
    val removed: Int = 0,
    val skippedNames: List<String> = emptyList(),
    val noPermission: Boolean = false,
)

fun SongEntity.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(uri)
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(Uri.parse(uri)) // resolved by ArtBitmapLoader (embedded cover)
            .build()
    )
    .build()

fun normalize(s: String): String =
    Normalizer.normalize(s.trim().lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

fun List<SongEntity>.toAlbums(): List<AlbumItem> =
    groupBy { it.album }.map { (name, l) ->
        val sorted = l.sortedWith(compareBy<SongEntity>({ it.trackNo }, { it.title.lowercase() }))
        val artists = sorted.map { it.artist }.distinct()
        AlbumItem(name, if (artists.size == 1) artists[0] else "", artists.size > 1, sorted)
    }.sortedBy { it.name.lowercase() }

fun List<SongEntity>.toArtists(): List<ArtistItem> =
    groupBy { it.artist }.map { (name, l) ->
        ArtistItem(name, l.sortedBy { it.title.lowercase() }, l.map { it.album }.distinct().size)
    }.sortedBy { it.name.lowercase() }

fun List<SongEntity>.toFolders(): List<FolderItem> =
    groupBy { it.folder }.map { (path, l) ->
        FolderItem(path, path.trimEnd('/').substringAfterLast('/').ifBlank { path }, l.sortedBy { it.title.lowercase() })
    }.sortedBy { it.name.lowercase() }

/** Hex-encodes arbitrary text so it is safe as a navigation route segment. */
fun String.toKey(): String = toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }
fun String.fromKey(): String = if (isEmpty()) "" else
    ByteArray(length / 2) { i -> substring(i * 2, i * 2 + 2).toInt(16).toByte() }.toString(Charsets.UTF_8)
