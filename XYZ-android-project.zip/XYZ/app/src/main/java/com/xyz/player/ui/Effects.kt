package com.xyz.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.xyz.player.R
import com.xyz.player.audio.AudioEngine
import com.xyz.player.audio.DspSettings
import com.xyz.player.audio.EqPreset
import com.xyz.player.audio.PlaybackRuntime
import kotlin.math.roundToInt

@Composable
fun EffectsScreen(vm: MainViewModel, nav: NavController) {
    val dsp by AudioEngine.dsp.collectAsStateWithLifecycle()
    val st by vm.player.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_effects)) {
            Text(stringResource(R.string.original_sound), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(end = 8.dp))
            Switch(checked = dsp.bypassAll, onCheckedChange = { b -> AudioEngine.update { it.copy(bypassAll = b) } }, modifier = Modifier.padding(end = 12.dp))
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
            Column(Modifier.padding(12.dp)) {
                SpectrumBars(st.isPlaying, Modifier.fillMaxWidth().height(48.dp))
                PeakMeter(st.isPlaying)
            }
        }
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(stringResource(R.string.equalizer)) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(stringResource(R.string.effects)) })
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (dsp.bypassAll) Text(stringResource(R.string.bypass_active), color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodyMedium)
            if (tab == 0) EqualizerTab(vm, dsp) else EffectsTab(vm, dsp)
        }
    }
}

@Composable
private fun PeakMeter(playing: Boolean) {
    var peak by remember { mutableStateOf(0f) }
    androidx.compose.runtime.LaunchedEffect(playing) {
        while (true) { peak = if (playing) AudioEngine.core.outPeak else 0f; kotlinx.coroutines.delay(80) }
    }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.peak), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
        LinearProgressIndicator(progress = { peak.coerceIn(0f, 1f) }, modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
            color = if (peak > 0.97f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Text(if (peak > 0.001f) "%.1f dB".format(20 * kotlin.math.log10(peak)) else "−∞", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 8.dp))
    }
}

// ---------------------------------------------------------------- Equalizer

@Composable
private fun EqualizerTab(vm: MainViewModel, dsp: DspSettings) {
    val profiles by vm.eqProfiles.collectAsStateWithLifecycle()
    var presetMenu by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val custom = dsp.presetId.removePrefix("custom:")
    val currentName = EqPreset.byId(dsp.presetId)?.let { stringResource(it.labelRes) }
        ?: if (dsp.presetId.startsWith("custom:")) custom else stringResource(R.string.preset_custom)

    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.equalizer_10), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.eq_engine_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = dsp.eqEnabled, onCheckedChange = { b -> AudioEngine.update { it.copy(eqEnabled = b) } })
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) {
            OutlinedButton(onClick = { presetMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.preset) + ": " + currentName, maxLines = 1) }
            DropdownMenu(presetMenu, { presetMenu = false }) {
                EqPreset.entries.forEach { p ->
                    DropdownMenuItem(text = { Text(stringResource(p.labelRes)) }, onClick = {
                        presetMenu = false
                        AudioEngine.update { it.copy(eqEnabled = true, bandsDb = p.gains, preampDb = p.autoPreamp, presetId = p.id) }
                    })
                }
                profiles.forEach { pr ->
                    DropdownMenuItem(text = { Text(pr.name) }, onClick = {
                        presetMenu = false
                        AudioEngine.update { it.copy(eqEnabled = true, bandsDb = pr.bands, preampDb = pr.preampDb, presetId = "custom:${pr.name}") }
                    })
                }
            }
        }
        TextButton(onClick = { saving = true }) { Icon(Icons.Rounded.Save, null); Text(stringResource(R.string.save_profile), modifier = Modifier.padding(start = 4.dp)) }
        TextButton(onClick = { AudioEngine.update { it.copy(bandsDb = List(DspSettings.BANDS) { 0f }, preampDb = 0f, presetId = "flat") } }) {
            Icon(Icons.Rounded.RestartAlt, null); Text(stringResource(R.string.reset), modifier = Modifier.padding(start = 4.dp))
        }
    }
    if (dsp.presetId.startsWith("custom:")) {
        TextButton(onClick = { vm.deleteEqProfile(custom) }) { Text(stringResource(R.string.delete_profile, custom)) }
    }
    LabeledSlider(R.string.preamp, dsp.preampDb, -12f..12f, "%+.1f dB".format(dsp.preampDb), enabled = dsp.eqEnabled, steps = 47) { v ->
        AudioEngine.update { it.copy(preampDb = v, presetId = markCustom(it)) }
    }
    Row(Modifier.fillMaxWidth()) {
        for (i in 0 until DspSettings.BANDS) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("%+.0f".format(dsp.bandsDb[i]), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                VerticalGainSlider(
                    value = dsp.bandsDb[i], enabled = dsp.eqEnabled, label = DspSettings.BAND_LABELS[i] + " Hz",
                    modifier = Modifier.height(190.dp).width(34.dp),
                ) { v -> AudioEngine.update { s -> s.copy(bandsDb = s.bandsDb.toMutableList().also { l -> l[i] = v }, presetId = markCustom(s)) } }
                Text(DspSettings.BAND_LABELS[i], style = MaterialTheme.typography.labelSmall)
            }
        }
    }
    Text(stringResource(R.string.eq_clip_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (saving) TextPromptDialog(R.string.save_profile, if (dsp.presetId.startsWith("custom:")) custom else "", R.string.save, { vm.saveEqProfile(it) }) { saving = false }
}

private fun markCustom(s: DspSettings): String = if (s.presetId.startsWith("custom:")) s.presetId else "custom"

@Composable
fun VerticalGainSlider(
    value: Float, enabled: Boolean, label: String, modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = -12f..12f, onChange: (Float) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val onChangeState by rememberUpdatedState(onChange)
    val active = if (enabled) cs.primary else cs.outline
    Canvas(
        modifier
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                fun upd(y: Float) {
                    val f = (1f - y / size.height).coerceIn(0f, 1f)
                    val v = range.start + f * (range.endInclusive - range.start)
                    onChangeState((v * 2).roundToInt() / 2f)
                }
                awaitEachGesture {
                    val down = awaitFirstDown()
                    upd(down.position.y)
                    do {
                        val ev = awaitPointerEvent()
                        ev.changes.forEach { if (it.pressed) { upd(it.position.y); it.consume() } }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .semantics {
                contentDescription = label
                stateDescription = "%+.1f dB".format(value)
                progressBarRangeInfo = ProgressBarRangeInfo(value, range, 23)
                setProgress { v -> onChangeState((v.coerceIn(range.start, range.endInclusive) * 2).roundToInt() / 2f); true }
            },
    ) {
        val cx = size.width / 2
        val trackW = 4.dp.toPx()
        drawRoundRect(cs.outlineVariant, Offset(cx - trackW / 2, 0f), Size(trackW, size.height), CornerRadius(trackW / 2))
        val zeroY = size.height * (1f - (0f - range.start) / (range.endInclusive - range.start))
        val y = size.height * (1f - (value - range.start) / (range.endInclusive - range.start))
        drawRoundRect(active, Offset(cx - trackW / 2, minOf(y, zeroY)), Size(trackW, kotlin.math.abs(zeroY - y).coerceAtLeast(1f)), CornerRadius(trackW / 2))
        drawLine(cs.outline, Offset(cx - 10.dp.toPx(), zeroY), Offset(cx + 10.dp.toPx(), zeroY), 1.dp.toPx())
        drawCircle(active, 10.dp.toPx(), Offset(cx, y))
        drawCircle(cs.background, 4.dp.toPx(), Offset(cx, y))
    }
}

// ---------------------------------------------------------------- Effects

@Composable
private fun EffectsTab(vm: MainViewModel, dsp: DspSettings) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val rg by PlaybackRuntime.replayGainDb.collectAsStateWithLifecycle()

    FxCard(R.string.fx_bass, R.string.fx_bass_desc, dsp.bassEnabled, { b -> AudioEngine.update { it.copy(bassEnabled = b) } }) {
        LabeledSlider(R.string.amount, dsp.bassAmount, 0f..1f, "+%.0f dB".format(dsp.bassAmount * 12), dsp.bassEnabled) { v -> AudioEngine.update { it.copy(bassAmount = v) } }
    }
    FxCard(R.string.fx_reverb, R.string.fx_reverb_desc, dsp.reverbEnabled, { b -> AudioEngine.update { it.copy(reverbEnabled = b) } }) {
        val on = dsp.reverbEnabled && !dsp.hallEnabled
        LabeledSlider(R.string.mix, dsp.reverbMix, 0f..1f, "%.0f %%".format(dsp.reverbMix * 100), on) { v -> AudioEngine.update { it.copy(reverbMix = v) } }
        LabeledSlider(R.string.decay, dsp.reverbDecay, 0.3f..6f, "%.1f s".format(dsp.reverbDecay), on) { v -> AudioEngine.update { it.copy(reverbDecay = v) } }
        LabeledSlider(R.string.damping, dsp.reverbDamping, 0f..1f, "%.0f %%".format(dsp.reverbDamping * 100), on) { v -> AudioEngine.update { it.copy(reverbDamping = v) } }
        if (dsp.hallEnabled) Text(stringResource(R.string.hall_overrides), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
    }
    FxCard(R.string.fx_hall, R.string.fx_hall_desc, dsp.hallEnabled, { b -> AudioEngine.update { it.copy(hallEnabled = b) } }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(R.string.hall_small, R.string.hall_concert, R.string.hall_large).forEachIndexed { i, r ->
                FilterChip(selected = dsp.hallProfile == i, onClick = { AudioEngine.update { it.copy(hallProfile = i) } }, label = { Text(stringResource(r)) }, enabled = dsp.hallEnabled)
            }
        }
    }
    FxCard(R.string.fx_spatial, R.string.fx_spatial_desc, dsp.spatialEnabled, { b -> AudioEngine.update { it.copy(spatialEnabled = b) } }) {
        LabeledSlider(R.string.amount, dsp.spatialAmount, 0f..1f, "%.0f %%".format(dsp.spatialAmount * 100), dsp.spatialEnabled) { v -> AudioEngine.update { it.copy(spatialAmount = v) } }
        Text(stringResource(R.string.fx_spatial_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    FxCard(R.string.fx_width, R.string.fx_width_desc, dsp.widthEnabled, { b -> AudioEngine.update { it.copy(widthEnabled = b) } }) {
        LabeledSlider(R.string.width, dsp.width, 0f..2f, "%.0f %%".format(dsp.width * 100), dsp.widthEnabled) { v -> AudioEngine.update { it.copy(width = v) } }
    }
    FxCard(R.string.fx_balance, R.string.fx_balance_desc, dsp.balance != 0f, null) {
        val txt = when { dsp.balance < -0.005f -> "L %.0f".format(-dsp.balance * 100); dsp.balance > 0.005f -> "R %.0f".format(dsp.balance * 100); else -> stringResource(R.string.center) }
        LabeledSlider(R.string.balance, dsp.balance, -1f..1f, txt, true) { v -> AudioEngine.update { it.copy(balance = if (kotlin.math.abs(v) < 0.04f) 0f else v) } }
    }
    FxCard(R.string.fx_normalize, R.string.fx_normalize_desc, dsp.normalize, { b -> AudioEngine.update { it.copy(normalize = b) } }) {
        Text(rg?.let { stringResource(R.string.rg_current, "%+.2f".format(it)) } ?: stringResource(R.string.rg_none), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    FxCard(R.string.fx_limiter, R.string.fx_limiter_desc, dsp.limiter, { b -> AudioEngine.update { it.copy(limiter = b) } }) {}
    FxCard(R.string.fx_crossfade, R.string.fx_crossfade_desc, settings.crossfadeMs > 0, null) {
        LabeledSlider(R.string.duration, settings.crossfadeMs / 1000f, 0f..10f, if (settings.crossfadeMs == 0) stringResource(R.string.off) else "%.0f s".format(settings.crossfadeMs / 1000f), true, steps = 9) { v -> vm.setCrossfade((v * 1000).roundToInt()) }
        Text(stringResource(R.string.fx_crossfade_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    OutlinedButton(onClick = { AudioEngine.setDsp(DspSettings()); vm.setCrossfade(0) }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Rounded.RestartAlt, null); Text(stringResource(R.string.reset_all_fx), modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun FxCard(titleRes: Int, descRes: Int, active: Boolean, onToggle: ((Boolean) -> Unit)?, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (active) cs.primary else cs.outlineVariant))
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(stringResource(titleRes), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(stringResource(descRes), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                if (onToggle != null) Switch(checked = active, onCheckedChange = onToggle)
                else Text(stringResource(if (active) R.string.on else R.string.off), style = MaterialTheme.typography.labelMedium, color = if (active) cs.primary else cs.onSurfaceVariant)
            }
            content()
        }
    }
}

@Composable
private fun LabeledSlider(labelRes: Int, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, enabled: Boolean, steps: Int = 0, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(stringResource(labelRes), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, enabled = enabled, steps = steps)
    }
}
