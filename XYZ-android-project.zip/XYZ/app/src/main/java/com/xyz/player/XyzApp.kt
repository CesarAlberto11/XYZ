package com.xyz.player

import android.app.Application
import androidx.room.Room
import com.xyz.player.audio.AudioEngine
import com.xyz.player.audio.PlaybackRuntime
import com.xyz.player.data.LibraryRepository
import com.xyz.player.data.Prefs
import com.xyz.player.data.XyzDb
import com.xyz.player.lyrics.LyricsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class XyzApp : Application() {
    lateinit var db: XyzDb; private set
    lateinit var prefs: Prefs; private set
    lateinit var lyrics: LyricsStore; private set
    lateinit var repo: LibraryRepository; private set
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, XyzDb::class.java, "xyz.db")
            .fallbackToDestructiveMigration() // v1: library can always be rescanned
            .build()
        prefs = Prefs(this)
        lyrics = LyricsStore(this)
        repo = LibraryRepository(this, db, prefs, lyrics)

        appScope.launch {
            AudioEngine.setDsp(prefs.loadDsp())
            launch { AudioEngine.dsp.drop(1).debounce(500).collect { prefs.saveDsp(it) } }
            launch { prefs.settings.map { it.crossfadeMs }.distinctUntilChanged().collect { PlaybackRuntime.crossfadeMs = it } }
        }
    }
}
