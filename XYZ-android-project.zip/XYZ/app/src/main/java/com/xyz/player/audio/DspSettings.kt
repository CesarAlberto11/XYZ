package com.xyz.player.audio

import org.json.JSONArray
import org.json.JSONObject

/** Every user-facing audio effect. Immutable: the audio thread compares instances by identity. */
data class DspSettings(
    val bypassAll: Boolean = false,
    val eqEnabled: Boolean = false,
    val preampDb: Float = 0f,
    val bandsDb: List<Float> = List(BANDS) { 0f },
    val presetId: String = "flat",
    val bassEnabled: Boolean = false,
    val bassAmount: Float = 0.5f,
    val reverbEnabled: Boolean = false,
    val reverbMix: Float = 0.25f,
    val reverbDecay: Float = 1.8f,
    val reverbDamping: Float = 0.5f,
    val hallEnabled: Boolean = false,
    val hallProfile: Int = 1, // 0 small room, 1 concert hall, 2 large hall
    val spatialEnabled: Boolean = false,
    val spatialAmount: Float = 0.5f,
    val widthEnabled: Boolean = false,
    val width: Float = 1f,
    val balance: Float = 0f,
    val normalize: Boolean = false,
    val limiter: Boolean = true,
) {
    fun toJson(): String = JSONObject().apply {
        put("bypassAll", bypassAll); put("eqEnabled", eqEnabled); put("preampDb", preampDb.toDouble())
        put("bandsDb", JSONArray().also { a -> bandsDb.forEach { a.put(it.toDouble()) } })
        put("presetId", presetId)
        put("bassEnabled", bassEnabled); put("bassAmount", bassAmount.toDouble())
        put("reverbEnabled", reverbEnabled); put("reverbMix", reverbMix.toDouble())
        put("reverbDecay", reverbDecay.toDouble()); put("reverbDamping", reverbDamping.toDouble())
        put("hallEnabled", hallEnabled); put("hallProfile", hallProfile)
        put("spatialEnabled", spatialEnabled); put("spatialAmount", spatialAmount.toDouble())
        put("widthEnabled", widthEnabled); put("width", width.toDouble())
        put("balance", balance.toDouble()); put("normalize", normalize); put("limiter", limiter)
    }.toString()

    companion object {
        const val BANDS = 10
        val BAND_FREQS = doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)
        val BAND_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

        fun fromJson(s: String): DspSettings {
            val o = JSONObject(s)
            val d = DspSettings()
            val arr = o.optJSONArray("bandsDb")
            val bands = if (arr != null && arr.length() == BANDS) List(BANDS) { arr.getDouble(it).toFloat() } else d.bandsDb
            fun f(k: String, def: Float) = o.optDouble(k, def.toDouble()).toFloat()
            return DspSettings(
                bypassAll = o.optBoolean("bypassAll", d.bypassAll),
                eqEnabled = o.optBoolean("eqEnabled", d.eqEnabled),
                preampDb = f("preampDb", d.preampDb),
                bandsDb = bands,
                presetId = o.optString("presetId", d.presetId),
                bassEnabled = o.optBoolean("bassEnabled", d.bassEnabled),
                bassAmount = f("bassAmount", d.bassAmount),
                reverbEnabled = o.optBoolean("reverbEnabled", d.reverbEnabled),
                reverbMix = f("reverbMix", d.reverbMix),
                reverbDecay = f("reverbDecay", d.reverbDecay),
                reverbDamping = f("reverbDamping", d.reverbDamping),
                hallEnabled = o.optBoolean("hallEnabled", d.hallEnabled),
                hallProfile = o.optInt("hallProfile", d.hallProfile).coerceIn(0, 2),
                spatialEnabled = o.optBoolean("spatialEnabled", d.spatialEnabled),
                spatialAmount = f("spatialAmount", d.spatialAmount),
                widthEnabled = o.optBoolean("widthEnabled", d.widthEnabled),
                width = f("width", d.width),
                balance = f("balance", d.balance),
                normalize = o.optBoolean("normalize", d.normalize),
                limiter = o.optBoolean("limiter", d.limiter),
            )
        }
    }
}
