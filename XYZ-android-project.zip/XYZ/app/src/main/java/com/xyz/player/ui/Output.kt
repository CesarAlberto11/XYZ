package com.xyz.player.ui

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.xyz.player.R
import com.xyz.player.audio.PlaybackRuntime

private fun typeRes(t: Int): Int = when (t) {
    AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> R.string.out_type_speaker
    AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL -> R.string.out_type_wired
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> R.string.out_type_bluetooth
    AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> R.string.out_type_usb
    AudioDeviceInfo.TYPE_HDMI, AudioDeviceInfo.TYPE_HDMI_ARC, AudioDeviceInfo.TYPE_HDMI_EARC -> R.string.out_type_hdmi
    else -> R.string.out_type_other
}

private fun isUsableOutput(d: AudioDeviceInfo) = d.isSink && d.type != AudioDeviceInfo.TYPE_TELEPHONY && d.type != AudioDeviceInfo.TYPE_BUILTIN_EARPIECE

/** Devices Android would route music to right now (API 33+), else null. */
fun activeOutputs(ctx: Context): List<AudioDeviceInfo>? {
    if (Build.VERSION.SDK_INT < 33) return null
    val am = ctx.getSystemService(AudioManager::class.java)
    val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    return runCatching { am.getAudioDevicesForAttributes(attrs) }.getOrNull()
}

fun describeActiveOutput(ctx: Context): String? {
    val d = activeOutputs(ctx)?.firstOrNull() ?: return null
    return "${d.productName} (${ctx.getString(typeRes(d.type))})"
}

@Composable
fun OutputScreen(nav: NavController) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(AudioManager::class.java) }
    var devices by remember { mutableStateOf(am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter(::isUsableOutput)) }
    var active by remember { mutableStateOf(activeOutputs(ctx)) }
    var preferred by remember { mutableStateOf<Int?>(null) }

    DisposableEffect(Unit) {
        val cb = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) { devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter(::isUsableOutput); active = activeOutputs(ctx) }
            override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) { devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter(::isUsableOutput); active = activeOutputs(ctx) }
        }
        am.registerAudioDeviceCallback(cb, null)
        onDispose { am.unregisterAudioDeviceCallback(cb) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.output), onBack = { nav.popBackStack() })
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.active_device), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    val a = active?.firstOrNull()
                    if (a != null) {
                        Text("${a.productName}", style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(typeRes(a.type)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else Text(stringResource(R.string.active_device_unknown), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    InfoRow(stringResource(R.string.mixer_rate), am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.let { "$it Hz" } ?: stringResource(R.string.not_available))
                }
            }
            Text(stringResource(R.string.connected_outputs), style = MaterialTheme.typography.titleMedium)
            if (devices.isEmpty()) Text(stringResource(R.string.not_available), color = MaterialTheme.colorScheme.onSurfaceVariant)
            devices.forEach { d ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${d.productName}", fontWeight = FontWeight.SemiBold)
                        Text(stringResource(typeRes(d.type)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (d.sampleRates.isNotEmpty()) Text(stringResource(R.string.supported_rates, d.sampleRates.joinToString(", ") { "${it / 1000f}" } + " kHz"), style = MaterialTheme.typography.bodySmall)
                        if (d.channelCounts.isNotEmpty()) Text(stringResource(R.string.supported_channels, d.channelCounts.joinToString(", ")), style = MaterialTheme.typography.bodySmall)
                        Row {
                            if (preferred == d.id) TextButton(onClick = { PlaybackRuntime.setPreferredDevice(null); preferred = null }) { Text(stringResource(R.string.use_system_default)) }
                            else TextButton(onClick = { PlaybackRuntime.setPreferredDevice(d); preferred = d.id }, enabled = PlaybackRuntime.player != null) { Text(stringResource(R.string.prefer_device)) }
                        }
                    }
                }
            }
            Text(stringResource(R.string.output_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = {
                val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_VOLUME) else Intent(Settings.ACTION_SOUND_SETTINGS)
                runCatching { ctx.startActivity(i) }
            }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.open_system_output)) }
            OutlinedButton(onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.open_bluetooth))
            }
            Text(stringResource(R.string.bitperfect_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
