package com.xyz.player.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.xyz.player.R
import com.xyz.player.data.AppSettings

data class Accent(val nameRes: Int, val color: Color)

val Accents = listOf(
    Accent(R.string.accent_blue, Color(0xFF2F7BFF)),
    Accent(R.string.accent_violet, Color(0xFF8B5CF6)),
    Accent(R.string.accent_emerald, Color(0xFF10B981)),
    Accent(R.string.accent_red, Color(0xFFEF4444)),
    Accent(R.string.accent_orange, Color(0xFFF97316)),
    Accent(R.string.accent_pink, Color(0xFFEC4899)),
    Accent(R.string.accent_cyan, Color(0xFF06B6D4)),
    Accent(R.string.accent_teal, Color(0xFF0D9488)),
    Accent(R.string.accent_lime, Color(0xFF84CC16)),
    Accent(R.string.accent_yellow, Color(0xFFEAB308)),
    Accent(R.string.accent_indigo, Color(0xFF4F46E5)),
    Accent(R.string.accent_magenta, Color(0xFFD946EF)),
    Accent(R.string.accent_coral, Color(0xFFFF6B5E)),
    Accent(R.string.accent_sky, Color(0xFF38BDF8)),
    Accent(R.string.accent_rose, Color(0xFFF43F5E)),
    Accent(R.string.accent_copper, Color(0xFFB45309)),
    Accent(R.string.accent_slate, Color(0xFF64748B)),
)

fun customAccent(hue: Float): Color = Color.hsv(hue.coerceIn(0f, 359f), 0.78f, 0.95f)

val LocalReduceMotion = compositionLocalOf { false }

private fun onColor(c: Color, light: Color, dark: Color) = if (c.luminance() > 0.42f) dark else light

private fun xyzScheme(accent: Color, dark: Boolean): ColorScheme {
    return if (dark) {
        // soft graphite (not pure black), panels slightly lighter with an accent tint
        val bg = lerp(Color(0xFF16181D), accent, 0.05f)
        val primary = lerp(accent, Color.White, 0.10f)
        darkColorScheme(
            primary = primary,
            onPrimary = onColor(primary, Color.White, Color(0xFF0E1014)),
            primaryContainer = lerp(Color(0xFF23262E), accent, 0.30f),
            onPrimaryContainer = Color.White,
            secondary = lerp(accent, Color(0xFFA8AFBF), 0.55f),
            onSecondary = Color(0xFF0E1014),
            secondaryContainer = lerp(Color(0xFF23262E), accent, 0.16f),
            onSecondaryContainer = Color(0xFFE8EAF0),
            tertiary = lerp(accent, Color(0xFFFFD27A), 0.45f),
            background = bg,
            onBackground = Color(0xFFF1F3F8),
            surface = lerp(Color(0xFF1D2026), accent, 0.04f),
            onSurface = Color(0xFFF1F3F8),
            surfaceVariant = lerp(Color(0xFF2A2E37), accent, 0.06f),
            onSurfaceVariant = Color(0xFFB0B6C4),
            outline = Color(0xFF5A6070),
            outlineVariant = Color(0xFF353A45),
            surfaceContainerLowest = lerp(Color(0xFF121418), accent, 0.03f),
            surfaceContainerLow = lerp(Color(0xFF1F2229), accent, 0.04f),
            surfaceContainer = lerp(Color(0xFF242830), accent, 0.05f),
            surfaceContainerHigh = lerp(Color(0xFF2B2F38), accent, 0.06f),
            surfaceContainerHighest = lerp(Color(0xFF343944), accent, 0.07f),
            error = Color(0xFFFF7A7A),
        )
    } else {
        // pearl background, white panels, graphite text
        val bg = lerp(Color(0xFFF2F4F8), accent, 0.035f)
        val primary = lerp(accent, Color.Black, if (accent.luminance() > 0.42f) 0.22f else 0.08f)
        lightColorScheme(
            primary = primary,
            onPrimary = onColor(primary, Color.White, Color(0xFF14161B)),
            primaryContainer = lerp(Color.White, accent, 0.22f),
            onPrimaryContainer = Color(0xFF12151C),
            secondary = lerp(accent, Color(0xFF5A6070), 0.6f),
            onSecondary = Color.White,
            secondaryContainer = lerp(Color.White, accent, 0.12f),
            onSecondaryContainer = Color(0xFF1B1E26),
            tertiary = lerp(accent, Color(0xFFB4690E), 0.5f),
            background = bg,
            onBackground = Color(0xFF12151C),
            surface = Color.White,
            onSurface = Color(0xFF12151C),
            surfaceVariant = lerp(Color(0xFFE9ECF2), accent, 0.04f),
            onSurfaceVariant = Color(0xFF5B6272),
            outline = Color(0xFF9AA0AE),
            outlineVariant = Color(0xFFDDE1E9),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFFCFCFE),
            surfaceContainer = lerp(Color(0xFFF6F7FA), accent, 0.02f),
            surfaceContainerHigh = lerp(Color(0xFFEEF0F5), accent, 0.04f),
            surfaceContainerHighest = lerp(Color(0xFFE6E9F0), accent, 0.05f),
            error = Color(0xFFC62828),
        )
    }
}

private val serif = FontFamily.Serif
private val XyzTypography = Typography().let { t ->
    t.copy(
        displayMedium = t.displayMedium.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        headlineLarge = t.headlineLarge.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        headlineSmall = t.headlineSmall.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
    )
}

// Generous radii everywhere: the whole UI is built from soft, curved surfaces.
private val XyzShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(40.dp),
)

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun systemReducesMotion(ctx: Context): Boolean =
    runCatching { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)

/** Soft bezier waves in the accent color behind every screen: the app's curved signature. */
@Composable
fun CurvedBackdrop(accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val top = Path().apply {
            moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h * 0.13f)
            cubicTo(w * 0.74f, h * 0.24f, w * 0.40f, h * 0.05f, 0f, h * 0.16f)
            close()
        }
        drawPath(top, Brush.linearGradient(listOf(accent.copy(alpha = 0.20f), accent.copy(alpha = 0.03f)), Offset(0f, 0f), Offset(w, h * 0.25f)))
        val top2 = Path().apply {
            moveTo(0f, 0f); lineTo(w * 0.62f, 0f)
            cubicTo(w * 0.50f, h * 0.07f, w * 0.22f, h * 0.10f, 0f, h * 0.075f)
            close()
        }
        drawPath(top2, accent.copy(alpha = 0.08f))
        val bottom = Path().apply {
            moveTo(0f, h); lineTo(0f, h * 0.88f)
            cubicTo(w * 0.30f, h * 0.81f, w * 0.66f, h * 0.96f, w, h * 0.85f)
            lineTo(w, h); close()
        }
        drawPath(bottom, accent.copy(alpha = 0.07f))
    }
}

@Composable
fun XyzTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) { 2 -> true; 0 -> isSystemInDarkTheme(); else -> false }
    val accent = if (settings.accent in Accents.indices) Accents[settings.accent].color else customAccent(settings.customHue)
    val scheme = remember(accent, dark) { xyzScheme(accent, dark) }
    val ctx = LocalContext.current
    val view = LocalView.current
    val reduce = settings.reduceMotion || systemReducesMotion(ctx)
    if (!view.isInEditMode) {
        SideEffect {
            val w = ctx.findActivity()?.window
            if (w != null) {
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalReduceMotion provides reduce) {
        MaterialTheme(colorScheme = scheme, typography = XyzTypography, shapes = XyzShapes) {
            Surface(Modifier.fillMaxSize(), color = scheme.background, contentColor = scheme.onBackground) {
                Box(Modifier.fillMaxSize()) {
                    CurvedBackdrop(scheme.primary)
                    content()
                }
            }
        }
    }
}
