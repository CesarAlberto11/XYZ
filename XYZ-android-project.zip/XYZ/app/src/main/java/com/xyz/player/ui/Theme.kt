package com.xyz.player.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.provider.Settings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.xyz.player.R
import com.xyz.player.data.AppSettings

data class Accent(val nameRes: Int, val color: Color)

val Accents = listOf(
    Accent(R.string.accent_blue, Color(0xFF2F7BFF)),
    Accent(R.string.accent_violet, Color(0xFF8B5CF6)),
    Accent(R.string.accent_emerald, Color(0xFF10B981)),
    Accent(R.string.accent_red, Color(0xFFEF4444)),
    Accent(R.string.accent_orange, Color(0xFFF97316)),
    Accent(R.string.accent_pink, Color(0xFFEC4899)),
    Accent(R.string.accent_cyan, Color(0xFF06B6D4)),
)

val LocalReduceMotion = compositionLocalOf { false }

private fun xyzScheme(accent: Color, dark: Boolean): ColorScheme {
    return if (dark) {
        val bg = lerp(Color(0xFF07080B), accent, 0.06f)
        val surface = lerp(Color(0xFF0F1116), accent, 0.07f)
        val high = lerp(Color(0xFF181B22), accent, 0.10f)
        val primary = lerp(accent, Color.White, 0.08f)
        darkColorScheme(
            primary = primary,
            onPrimary = if (primary.luminance() > 0.45f) Color(0xFF0A0B0F) else Color.White,
            primaryContainer = lerp(surface, accent, 0.32f),
            onPrimaryContainer = Color.White,
            secondary = lerp(accent, Color(0xFF9AA0AE), 0.55f),
            onSecondary = Color(0xFF0A0B0F),
            secondaryContainer = lerp(surface, accent, 0.18f),
            onSecondaryContainer = Color(0xFFE6E8EE),
            tertiary = lerp(accent, Color(0xFFFFC857), 0.45f),
            background = bg,
            onBackground = Color(0xFFECEEF3),
            surface = surface,
            onSurface = Color(0xFFECEEF3),
            surfaceVariant = high,
            onSurfaceVariant = Color(0xFFA2A8B6),
            outline = Color(0xFF454B58),
            outlineVariant = Color(0xFF2A2E38),
            surfaceContainerLowest = lerp(Color(0xFF050608), accent, 0.04f),
            surfaceContainerLow = surface,
            surfaceContainer = lerp(Color(0xFF13161C), accent, 0.08f),
            surfaceContainerHigh = high,
            surfaceContainerHighest = lerp(Color(0xFF1E222A), accent, 0.12f),
            error = Color(0xFFFF6B6B),
        )
    } else {
        val bg = lerp(Color(0xFFF4F5F8), accent, 0.04f)
        val primary = lerp(accent, Color.Black, 0.12f)
        lightColorScheme(
            primary = primary,
            onPrimary = Color.White,
            primaryContainer = lerp(Color.White, accent, 0.22f),
            onPrimaryContainer = Color(0xFF111318),
            secondary = lerp(accent, Color(0xFF5A6070), 0.6f),
            onSecondary = Color.White,
            secondaryContainer = lerp(Color.White, accent, 0.12f),
            onSecondaryContainer = Color(0xFF1B1E26),
            tertiary = lerp(accent, Color(0xFFB4690E), 0.5f),
            background = bg,
            onBackground = Color(0xFF14161B),
            surface = lerp(Color.White, accent, 0.02f),
            onSurface = Color(0xFF14161B),
            surfaceVariant = lerp(Color(0xFFE9EBF1), accent, 0.05f),
            onSurfaceVariant = Color(0xFF555B69),
            outline = Color(0xFF9096A5),
            outlineVariant = Color(0xFFD5D8E0),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = lerp(Color(0xFFF8F9FB), accent, 0.02f),
            surfaceContainer = lerp(Color(0xFFEFF1F5), accent, 0.04f),
            surfaceContainerHigh = lerp(Color(0xFFE8EAF0), accent, 0.05f),
            surfaceContainerHighest = lerp(Color(0xFFE1E4EB), accent, 0.06f),
            error = Color(0xFFC62828),
        )
    }
}

private val serif = FontFamily.Serif
private val XyzTypography = Typography().let { t ->
    t.copy(
        displayMedium = t.displayMedium.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        headlineLarge = t.headlineLarge.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        headlineSmall = t.headlineSmall.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontFamily = serif, fontWeight = FontWeight.SemiBold),
    )
}

private val XyzShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(6.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(32.dp),
)

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun systemReducesMotion(ctx: Context): Boolean =
    runCatching { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)

@Composable
fun XyzTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val accent = Accents[settings.accent.coerceIn(0, Accents.lastIndex)].color
    val scheme = remember(accent, dark) { xyzScheme(accent, dark) }
    val ctx = LocalContext.current
    val view = LocalView.current
    val reduce = settings.reduceMotion || systemReducesMotion(ctx)
    if (!view.isInEditMode) {
        SideEffect {
            val w = ctx.findActivity()?.window
            if (w != null) {
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalReduceMotion provides reduce) {
        MaterialTheme(colorScheme = scheme, typography = XyzTypography, shapes = XyzShapes) {
            Surface(Modifier.fillMaxSize(), color = scheme.background, content = content)
        }
    }
}
