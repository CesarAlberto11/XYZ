package com.xyz.player.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** RBJ biquad, transposed direct form II, per-channel state. */
class Biquad(channels: Int) {
    private var b0 = 1.0; private var b1 = 0.0; private var b2 = 0.0
    private var a1 = 0.0; private var a2 = 0.0
    private val z1 = DoubleArray(channels)
    private val z2 = DoubleArray(channels)

    fun identity() { b0 = 1.0; b1 = 0.0; b2 = 0.0; a1 = 0.0; a2 = 0.0 }
    fun reset() { z1.fill(0.0); z2.fill(0.0) }

    fun peaking(fs: Double, f0: Double, gainDb: Double, q: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs
        val alpha = sin(w0) / (2 * q)
        val cw = cos(w0)
        val a0 = 1 + alpha / a
        b0 = (1 + alpha * a) / a0; b1 = (-2 * cw) / a0; b2 = (1 - alpha * a) / a0
        a1 = (-2 * cw) / a0; a2 = (1 - alpha / a) / a0
    }

    fun lowShelf(fs: Double, f0: Double, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2 * PI * f0 / fs
        val cw = cos(w0)
        val alpha = sin(w0) / 2 * sqrt(2.0) // shelf slope S = 1
        val t = 2 * sqrt(a) * alpha
        val a0 = (a + 1) + (a - 1) * cw + t
        b0 = a * ((a + 1) - (a - 1) * cw + t) / a0
        b1 = 2 * a * ((a - 1) - (a + 1) * cw) / a0
        b2 = a * ((a + 1) - (a - 1) * cw - t) / a0
        a1 = -2 * ((a - 1) + (a + 1) * cw) / a0
        a2 = ((a + 1) + (a - 1) * cw - t) / a0
    }

    fun process(ch: Int, x: Double): Double {
        val y = b0 * x + z1[ch]
        z1[ch] = b1 * x - a1 * y + z2[ch]
        z2[ch] = b2 * x - a2 * y
        return y
    }
}

private class Comb(size: Int) {
    private val buf = FloatArray(size)
    private var idx = 0
    private var store = 0f
    val length = size
    fun process(x: Float, feedback: Float, damp: Float): Float {
        val out = buf[idx]
        store = out * (1f - damp) + store * damp
        buf[idx] = x + store * feedback
        if (++idx >= buf.size) idx = 0
        return out
    }
    fun clear() { buf.fill(0f); store = 0f }
}

private class AllPass(size: Int) {
    private val buf = FloatArray(size)
    private var idx = 0
    fun process(x: Float): Float {
        val b = buf[idx]
        val out = -x + b
        buf[idx] = x + b * 0.5f
        if (++idx >= buf.size) idx = 0
        return out
    }
    fun clear() = buf.fill(0f)
}

/** Schroeder/Freeverb style reverberator with a real RT60 control. */
class Reverb(private val sampleRate: Int) {
    private val combTuning = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val allTuning = intArrayOf(556, 441, 341, 225)
    private fun scale(n: Int) = max(8, (n.toLong() * sampleRate / 44100).toInt())

    private val combL = Array(8) { Comb(scale(combTuning[it])) }
    private val combR = Array(8) { Comb(scale(combTuning[it] + 23)) }
    private val apL = Array(4) { AllPass(scale(allTuning[it])) }
    private val apR = Array(4) { AllPass(scale(allTuning[it] + 23)) }
    private val fbL = FloatArray(8)
    private val fbR = FloatArray(8)
    private var damp = 0.3f
    private var inGain = 0.015f
    private var curRt = -1f

    var outL = 0f; private set
    var outR = 0f; private set

    fun setParams(rt60: Float, damping: Float) {
        damp = (0.05f + damping.coerceIn(0f, 1f) * 0.6f)
        if (rt60 == curRt) return
        curRt = rt60
        val rt = rt60.coerceIn(0.2f, 8f).toDouble()
        var sum = 0f
        for (i in 0 until 8) {
            fbL[i] = min(0.985, 10.0.pow(-3.0 * combL[i].length / (sampleRate * rt))).toFloat()
            fbR[i] = min(0.985, 10.0.pow(-3.0 * combR[i].length / (sampleRate * rt))).toFloat()
            sum += fbL[i]
        }
        inGain = 0.094f * (1f - sum / 8f) // keeps the steady-state tail level independent of decay time
    }

    fun clear() { combL.forEach { it.clear() }; combR.forEach { it.clear() }; apL.forEach { it.clear() }; apR.forEach { it.clear() } }

    fun process(inL: Float, inR: Float) {
        val inp = (inL + inR) * inGain
        var wl = 0f; var wr = 0f
        for (i in 0 until 8) { wl += combL[i].process(inp, fbL[i], damp); wr += combR[i].process(inp, fbR[i], damp) }
        for (i in 0 until 4) { wl = apL[i].process(wl); wr = apR[i].process(wr) }
        outL = wl; outR = wr
    }
}

/**
 * Pure-Kotlin DSP chain: preamp -> 10-band EQ -> bass shelf -> ReplayGain -> stereo width/spatial ->
 * balance -> reverb/hall -> peak limiter. Operates in-place on interleaved float samples.
 * [settings] may be written from any thread; everything else runs on the audio thread.
 */
class DspCore {
    @Volatile var settings = DspSettings()
    @Volatile var replayGainDb = 0f
    @Volatile var spectrumEnabled = false
    @Volatile var spectrum = FloatArray(SPECTRUM_BANDS)
        private set
    @Volatile var outPeak = 0f
        private set

    private var sr = 44100
    private var ch = 2
    private var bq = Array(DspSettings.BANDS) { Biquad(2) }
    private var bass = Biquad(2)
    private var rev = Reverb(44100)
    private var applied: DspSettings? = null
    private var appliedRg = Float.NaN

    private var eqBands = IntArray(0)
    private var preGain = 1.0
    private var eqOn = false
    private var bassOn = false
    private var rgGain = 1f
    private var stereoFx = false
    private var widthV = 1f
    private var spatialOn = false
    private var spatialGain = 0f
    private var balL = 1f
    private var balR = 1f
    private var reverbOn = false
    private var revMix = 0f
    private var limiterOn = true
    private var limGain = 1f
    private var relCoef = 0.0003f
    private var sideLp = 0f
    private var sideA = 0.2f
    private var smooth = FloatArray(SPECTRUM_BANDS)

    // spectrum analysis
    private val fftRe = FloatArray(FFT_N)
    private val fftIm = FloatArray(FFT_N)
    private val window = FloatArray(FFT_N) { (0.5 - 0.5 * cos(2 * PI * it / (FFT_N - 1))).toFloat() }
    private val fftIn = FloatArray(FFT_N)
    private var fftPos = 0

    fun configure(sampleRate: Int, channels: Int) {
        sr = sampleRate; ch = channels
        bq = Array(DspSettings.BANDS) { Biquad(channels) }
        bass = Biquad(channels)
        rev = Reverb(sampleRate)
        applied = null; appliedRg = Float.NaN
        limGain = 1f; sideLp = 0f; fftPos = 0
        relCoef = (1.0 - exp(-1.0 / (0.15 * sampleRate))).toFloat()
        sideA = (1.0 - exp(-2 * PI * 1500.0 / sampleRate)).toFloat()
    }

    fun reset() {
        bq.forEach { it.reset() }; bass.reset(); rev.clear(); limGain = 1f; sideLp = 0f
    }

    private fun apply(s: DspSettings) {
        val fx = !s.bypassAll
        val fs = sr.toDouble()
        val act = ArrayList<Int>()
        for (i in 0 until DspSettings.BANDS) {
            val g = s.bandsDb.getOrElse(i) { 0f }.toDouble().coerceIn(-12.0, 12.0)
            if (DspSettings.BAND_FREQS[i] < fs * 0.45 && abs(g) >= 0.05) {
                bq[i].peaking(fs, DspSettings.BAND_FREQS[i], g, 1.41); act += i
            } else bq[i].identity()
        }
        eqBands = act.toIntArray()
        preGain = 10.0.pow(s.preampDb.toDouble().coerceIn(-12.0, 12.0) / 20.0)
        eqOn = fx && s.eqEnabled && (eqBands.isNotEmpty() || abs(preGain - 1.0) > 1e-4)

        bassOn = fx && s.bassEnabled && s.bassAmount > 0.01f
        if (bassOn) bass.lowShelf(fs, 110.0, s.bassAmount.coerceIn(0f, 1f) * 12.0) else bass.identity()

        widthV = if (fx && s.widthEnabled) s.width.coerceIn(0f, 2f) else 1f
        spatialOn = fx && s.spatialEnabled && s.spatialAmount > 0.01f
        spatialGain = s.spatialAmount.coerceIn(0f, 1f) * 1.6f
        stereoFx = ch == 2 && (spatialOn || widthV != 1f)
        val bal = if (fx) s.balance.coerceIn(-1f, 1f) else 0f
        balL = if (bal > 0) 1f - bal else 1f
        balR = if (bal < 0) 1f + bal else 1f

        reverbOn = ch == 2 && fx && (s.hallEnabled || s.reverbEnabled)
        if (reverbOn) {
            if (s.hallEnabled) {
                when (s.hallProfile) {
                    0 -> { rev.setParams(0.7f, 0.55f); revMix = 0.22f }
                    2 -> { rev.setParams(4.2f, 0.30f); revMix = 0.34f }
                    else -> { rev.setParams(2.4f, 0.35f); revMix = 0.30f }
                }
            } else {
                rev.setParams(s.reverbDecay, s.reverbDamping); revMix = s.reverbMix.coerceIn(0f, 1f)
            }
        }
        limiterOn = fx && s.limiter
        appliedRg = Float.NaN // force ReplayGain gain recompute
        applied = s
    }

    fun process(buf: FloatArray, frames: Int) {
        val s = settings
        if (s !== applied) apply(s)
        val rg = replayGainDb
        if (rg != appliedRg) {
            appliedRg = rg
            rgGain = if (!s.bypassAll && s.normalize) 10.0.pow(rg.coerceIn(-15f, 15f) / 20.0).toFloat() else 1f
        }
        val c = ch
        var pk = 0f
        for (f in 0 until frames) {
            val base = f * c
            if (c == 2) {
                var l = buf[base]; var r = buf[base + 1]
                if (eqOn) {
                    var yl = l * preGain; var yr = r * preGain
                    for (b in eqBands) { yl = bq[b].process(0, yl); yr = bq[b].process(1, yr) }
                    l = yl.toFloat(); r = yr.toFloat()
                }
                if (bassOn) { l = bass.process(0, l.toDouble()).toFloat(); r = bass.process(1, r.toDouble()).toFloat() }
                if (rgGain != 1f) { l *= rgGain; r *= rgGain }
                if (stereoFx) {
                    val m = (l + r) * 0.5f
                    var sd = (l - r) * 0.5f * widthV
                    if (spatialOn) { sideLp += (sd - sideLp) * sideA; sd += (sd - sideLp) * spatialGain }
                    l = m + sd; r = m - sd
                }
                if (balL != 1f || balR != 1f) { l *= balL; r *= balR }
                if (reverbOn) {
                    rev.process(l, r)
                    l = l * (1f - 0.35f * revMix) + rev.outL * revMix * 1.2f
                    r = r * (1f - 0.35f * revMix) + rev.outR * revMix * 1.2f
                }
                if (limiterOn) {
                    val p = max(abs(l), abs(r))
                    val target = if (p > 0.98f) 0.98f / p else 1f
                    limGain = if (target < limGain) limGain + (target - limGain) * 0.5f else limGain + (target - limGain) * relCoef
                    l *= limGain; r *= limGain
                }
                l = l.coerceIn(-1f, 1f); r = r.coerceIn(-1f, 1f)
                buf[base] = l; buf[base + 1] = r
                pk = max(pk, max(abs(l), abs(r)))
                if (spectrumEnabled) feedSpectrum((l + r) * 0.5f)
            } else {
                var p = 0f
                for (k in 0 until c) {
                    var x = buf[base + k]
                    if (eqOn) {
                        var y = x * preGain
                        for (b in eqBands) y = bq[b].process(k, y)
                        x = y.toFloat()
                    }
                    if (bassOn) x = bass.process(k, x.toDouble()).toFloat()
                    if (rgGain != 1f) x *= rgGain
                    buf[base + k] = x
                    p = max(p, abs(x))
                }
                if (limiterOn) {
                    val target = if (p > 0.98f) 0.98f / p else 1f
                    limGain = if (target < limGain) limGain + (target - limGain) * 0.5f else limGain + (target - limGain) * relCoef
                }
                for (k in 0 until c) {
                    val v = (buf[base + k] * (if (limiterOn) limGain else 1f)).coerceIn(-1f, 1f)
                    buf[base + k] = v
                    pk = max(pk, abs(v))
                }
                if (spectrumEnabled) feedSpectrum(buf[base])
            }
        }
        outPeak = max(pk, outPeak * 0.92f)
    }

    private fun feedSpectrum(x: Float) {
        fftIn[fftPos++] = x
        if (fftPos < FFT_N) return
        fftPos = 0
        for (i in 0 until FFT_N) { fftRe[i] = fftIn[i] * window[i]; fftIm[i] = 0f }
        fft(fftRe, fftIm)
        val nyq = sr / 2.0
        val hi = min(16000.0, nyq * 0.95)
        val lo = 40.0
        val out = FloatArray(SPECTRUM_BANDS)
        for (b in 0 until SPECTRUM_BANDS) {
            val f0 = lo * (hi / lo).pow(b.toDouble() / SPECTRUM_BANDS)
            val f1 = lo * (hi / lo).pow((b + 1.0) / SPECTRUM_BANDS)
            val k0 = (f0 * FFT_N / sr).toInt().coerceIn(1, FFT_N / 2 - 1)
            val k1 = max(k0 + 1, (f1 * FFT_N / sr).toInt()).coerceAtMost(FFT_N / 2)
            var m = 0f
            for (k in k0 until k1) m = max(m, sqrt(fftRe[k] * fftRe[k] + fftIm[k] * fftIm[k]))
            val amp = m / (FFT_N / 4f)
            val db = 20f * log10(amp + 1e-6f)
            val level = ((db + 72f) / 72f).coerceIn(0f, 1f)
            smooth[b] = max(level, smooth[b] * 0.82f)
            out[b] = smooth[b]
        }
        spectrum = out
    }

    companion object {
        const val FFT_N = 1024
        const val SPECTRUM_BANDS = 32

        /** In-place iterative radix-2 FFT. */
        fun fft(re: FloatArray, im: FloatArray) {
            val n = re.size
            var j = 0
            for (i in 1 until n) {
                var bit = n shr 1
                while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
                j = j xor bit
                if (i < j) {
                    val tr = re[i]; re[i] = re[j]; re[j] = tr
                    val ti = im[i]; im[i] = im[j]; im[j] = ti
                }
            }
            var len = 2
            while (len <= n) {
                val ang = -2 * PI / len
                val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
                var i = 0
                while (i < n) {
                    var cr = 1f; var ci = 0f
                    val half = len / 2
                    for (k in 0 until half) {
                        val a = i + k; val b = a + half
                        val vr = re[b] * cr - im[b] * ci
                        val vi = re[b] * ci + im[b] * cr
                        re[b] = re[a] - vr; im[b] = im[a] - vi
                        re[a] += vr; im[a] += vi
                        val ncr = cr * wr - ci * wi
                        ci = cr * wi + ci * wr
                        cr = ncr
                    }
                    i += len
                }
                len = len shl 1
            }
        }
    }
}
