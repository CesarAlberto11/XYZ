package com.xyz.player.audio

import com.xyz.player.R

/** Factory presets (gains in dB for 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k Hz). */
enum class EqPreset(val id: String, val labelRes: Int, val gains: List<Float>) {
    FLAT("flat", R.string.preset_flat, listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f)),
    BASS_BOOST("bass_boost", R.string.preset_bass_boost, listOf(6f, 5f, 4f, 2f, 1f, 0f, 0f, 0f, 0f, 0f)),
    DEEP_BASS("deep_bass", R.string.preset_deep_bass, listOf(8f, 7f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f)),
    ROCK("rock", R.string.preset_rock, listOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f)),
    POP("pop", R.string.preset_pop, listOf(-1f, 2f, 4f, 5f, 3f, 0f, -1f, -1f, -2f, -2f)),
    JAZZ("jazz", R.string.preset_jazz, listOf(3f, 2f, 1f, 2f, -1f, -1f, 0f, 1f, 2f, 3f)),
    CLASSICAL("classical", R.string.preset_classical, listOf(0f, 0f, 0f, 0f, 0f, 0f, -3f, -3f, -3f, -5f)),
    ELECTRONIC("electronic", R.string.preset_electronic, listOf(5f, 4f, 1f, 0f, -2f, 2f, 1f, 1f, 4f, 5f)),
    HIP_HOP("hip_hop", R.string.preset_hip_hop, listOf(5f, 4f, 2f, 3f, -1f, -1f, 2f, -1f, 2f, 3f)),
    VOCAL("vocal", R.string.preset_vocal, listOf(-2f, -3f, -3f, 1f, 4f, 4f, 3f, 1f, 0f, -1f)),
    ACOUSTIC("acoustic", R.string.preset_acoustic, listOf(4f, 4f, 3f, 1f, 2f, 2f, 3f, 3f, 3f, 2f)),
    TREBLE_BOOST("treble_boost", R.string.preset_treble_boost, listOf(0f, 0f, 0f, 0f, 0f, 1f, 3f, 5f, 6f, 7f));

    /** Negative preamp that compensates the largest boost, so presets do not clip. */
    val autoPreamp: Float
        get() = -(Math.round((gains.maxOrNull() ?: 0f).coerceAtLeast(0f) * 0.6f * 2f) / 2f)

    companion object {
        fun byId(id: String): EqPreset? = entries.firstOrNull { it.id == id }
    }
}
