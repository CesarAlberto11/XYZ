package com.xyz.player.playback

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.extractor.metadata.id3.CommentFrame
import androidx.media3.extractor.metadata.id3.TextInformationFrame
import androidx.media3.extractor.metadata.vorbis.VorbisComment
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.xyz.player.XyzApp
import com.xyz.player.audio.AudioEngine
import com.xyz.player.audio.PlaybackRuntime
import com.xyz.player.audio.SleepTimer
import com.xyz.player.audio.TechInfo
import com.xyz.player.audio.XyzDspProcessor
import com.xyz.player.data.toMediaItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min

/**
 * Foreground media service. Owns the ExoPlayer, the MediaSession (notification, lock screen, headset buttons,
 * Bluetooth/Auto controllers) and the audio processor chain. Playback never depends on the Activity.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var lastCounted: String? = null
    private var tick = 0
    private val app get() = application as XyzApp

    private val saveRunnable = Runnable { saveSession() }
    private val ticker = object : Runnable {
        override fun run() {
            applyFade()
            if (++tick % 100 == 0) saveSession()
            handler.postDelayed(this, 100)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val factory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink =
                DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessorChain(DefaultAudioSink.DefaultAudioProcessorChain(XyzDspProcessor(AudioEngine.core)))
                    .build()
        }
        factory.setEnableAudioFloatOutput(true)
        factory.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)

        player = ExoPlayer.Builder(this, factory)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        PlaybackRuntime.player = player

        session = MediaSession.Builder(this, player)
            .setCallback(Callback())
            .setBitmapLoader(ArtBitmapLoader(this))
            .build()

        player.addListener(object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_TIMELINE_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_REPEAT_MODE_CHANGED, Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED,
                    )
                ) scheduleSave()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(ticker)
                if (isPlaying) { handler.post(ticker); countPlayed() }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                lastCounted = null
                PlaybackRuntime.embeddedLyrics.value = null
                if (player.isPlaying || reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) countPlayed()
            }

            override fun onTracksChanged(tracks: Tracks) { readTrackInfo(tracks) }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) SleepTimer.onEndOfTrackPause()
            }

            override fun onPlayerError(error: PlaybackException) {
                val title = player.currentMediaItem?.mediaMetadata?.title?.toString().orEmpty()
                PlaybackRuntime.errors.tryEmit(title)
                // corrupted / unsupported file: skip to the next one instead of stalling
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem(); player.prepare(); player.play()
                } else player.prepare()
            }
        })

        restoreSession()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveSession()
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        saveSession()
        session?.run { release(); session = null }
        PlaybackRuntime.player = null
        player.release()
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ callbacks

    private inner class Callback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { it.buildUpon().setUri(it.mediaId).build() }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun countPlayed() {
        val id = player.currentMediaItem?.mediaId ?: return
        if (id.isEmpty() || id == lastCounted) return
        lastCounted = id
        scope.launch(Dispatchers.IO) { app.repo.markPlayed(id) }
    }

    /** Simple fade-out/fade-in around track boundaries (sequential, not overlapping). */
    private fun applyFade() {
        val fade = PlaybackRuntime.crossfadeMs
        if (fade <= 0) { if (player.volume != 1f) player.volume = 1f; return }
        val dur = player.duration
        if (dur == C.TIME_UNSET || dur <= 0) return
        val f = min(fade.toLong(), dur / 3).coerceAtLeast(1L)
        val pos = player.currentPosition
        val v = min(1f, min(pos.toFloat() / f, (dur - pos).toFloat() / f)).coerceIn(0f, 1f)
        if (kotlin.math.abs(v - player.volume) > 0.01f) player.volume = v
    }

    private fun scheduleSave() {
        handler.removeCallbacks(saveRunnable)
        handler.postDelayed(saveRunnable, 1500)
    }

    private fun saveSession() {
        val n = player.mediaItemCount
        if (n == 0) return
        val uris = ArrayList<String>(n)
        for (i in 0 until n) uris.add(player.getMediaItemAt(i).mediaId)
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        val sh = player.shuffleModeEnabled
        val rep = player.repeatMode
        scope.launch(Dispatchers.IO) { app.prefs.saveSession(uris, idx, pos, sh, rep) }
    }

    private fun restoreSession() {
        scope.launch {
            val settings = withContext(Dispatchers.IO) { app.prefs.settings.first() }
            PlaybackRuntime.crossfadeMs = settings.crossfadeMs
            player.playbackParameters = PlaybackParameters(settings.speed, if (settings.pitchLinked) settings.speed else 1f)
            val s = withContext(Dispatchers.IO) { app.prefs.loadSession() } ?: return@launch
            if (player.mediaItemCount > 0) return@launch
            val songs = withContext(Dispatchers.IO) { app.repo.songsByUris(s.uris) }
            val items = s.uris.mapNotNull { songs[it]?.toMediaItem() }
            if (items.isEmpty()) return@launch
            val wanted = s.uris.getOrNull(s.index)
            val idx = items.indexOfFirst { it.mediaId == wanted }.coerceAtLeast(0)
            player.setMediaItems(items, idx, s.positionMs)
            player.shuffleModeEnabled = s.shuffle
            player.repeatMode = s.repeat
            player.prepare() // stays paused until the user presses play
        }
    }

    private fun readTrackInfo(tracks: Tracks) {
        val id = player.currentMediaItem?.mediaId
        var rg: Float? = null
        var lyrics: String? = null
        var tech: TechInfo? = null
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSelected(i)) continue
                val f = g.getTrackFormat(i)
                tech = TechInfo(
                    mediaId = id, mime = f.sampleMimeType, codecs = f.codecs, sampleRate = f.sampleRate,
                    channels = f.channelCount, bitrate = if (f.averageBitrate > 0) f.averageBitrate else f.bitrate,
                    pcmBits = when (f.pcmEncoding) {
                        C.ENCODING_PCM_8BIT -> 8
                        C.ENCODING_PCM_16BIT, C.ENCODING_PCM_16BIT_BIG_ENDIAN -> 16
                        C.ENCODING_PCM_24BIT -> 24
                        C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 32
                        else -> null
                    },
                )
                val md = f.metadata ?: continue
                for (k in 0 until md.length()) {
                    when (val e = md.get(k)) {
                        is TextInformationFrame -> {
                            if (e.id == "TXXX" && e.description.equals("REPLAYGAIN_TRACK_GAIN", true)) rg = parseGain(e.values.firstOrNull())
                            if (e.id == "USLT" && !e.values.firstOrNull().isNullOrBlank()) lyrics = e.values.firstOrNull()
                            if (e.id == "TXXX" && (e.description.equals("LYRICS", true) || e.description.equals("UNSYNCEDLYRICS", true))) lyrics = e.values.firstOrNull()
                        }
                        is CommentFrame -> if (e.id == "USLT" && e.text.isNotBlank()) lyrics = e.text
                        is VorbisComment -> {
                            if (e.key.equals("REPLAYGAIN_TRACK_GAIN", true)) rg = parseGain(e.value)
                            if (e.key.equals("LYRICS", true) || e.key.equals("UNSYNCEDLYRICS", true)) lyrics = e.value
                        }
                        else -> {}
                    }
                }
            }
        }
        PlaybackRuntime.tech.value = tech
        PlaybackRuntime.replayGainDb.value = rg
        AudioEngine.core.replayGainDb = rg ?: 0f
        if (id != null && !lyrics.isNullOrBlank()) PlaybackRuntime.embeddedLyrics.value = id to lyrics!!
    }

    private fun parseGain(s: String?): Float? =
        s?.lowercase()?.replace("db", "")?.trim()?.toFloatOrNull()
}
