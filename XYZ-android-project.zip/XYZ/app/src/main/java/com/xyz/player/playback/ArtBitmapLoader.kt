package com.xyz.player.playback

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.util.BitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.xyz.player.data.ArtLoader
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Supplies notification / lock-screen artwork by reading the cover embedded in the audio file itself. */
class ArtBitmapLoader(private val ctx: Context) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> =
        exec.submit(Callable<Bitmap> { BitmapFactory.decodeByteArray(data, 0, data.size) ?: error("decode failed") })

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> =
        exec.submit(Callable<Bitmap> { ArtLoader.load(ctx, uri.toString(), 512) ?: error("no artwork") })
}
