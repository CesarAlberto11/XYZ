package com.xyz.player.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/** source: 0 = MediaStore, 1 = authorized folder (SAF), 2 = individually imported file */
@Entity(tableName = "songs", indices = [Index("dedupKey"), Index("source")])
data class SongEntity(
    @PrimaryKey val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val year: Int,
    val trackNo: Int,
    val durationMs: Long,
    val folder: String,
    val mime: String,
    val dateAdded: Long,
    val source: Int,
    val dedupKey: String,
    val favorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayed: Long = 0L,
    val edited: Boolean = false,
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "playlist_entries", indices = [Index("playlistId")])
data class PlaylistEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val songUri: String,
    val position: Int,
)

@Dao
interface SongDao {
    @Query("SELECT * FROM songs")
    fun observeAll(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs")
    suspend fun getAll(): List<SongEntity>

    @Query("SELECT * FROM songs WHERE uri IN (:uris)")
    suspend fun getByUris(uris: List<String>): List<SongEntity>

    @Upsert
    suspend fun upsertAll(songs: List<SongEntity>)

    @Query("DELETE FROM songs WHERE uri IN (:uris)")
    suspend fun deleteByUris(uris: List<String>)

    @Query("UPDATE songs SET favorite = :fav WHERE uri IN (:uris)")
    suspend fun setFavorite(uris: List<String>, fav: Boolean)

    @Query("UPDATE songs SET playCount = playCount + 1, lastPlayed = :ts WHERE uri = :uri")
    suspend fun markPlayed(uri: String, ts: Long)

    @Query("UPDATE songs SET title = :title, artist = :artist, album = :album, edited = 1 WHERE uri = :uri")
    suspend fun editMeta(uri: String, title: String, artist: String, album: String)
}

@Dao
abstract class PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    abstract fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlist_entries ORDER BY playlistId, position")
    abstract fun observeEntries(): Flow<List<PlaylistEntry>>

    @Insert
    abstract suspend fun insertPlaylist(p: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    abstract suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :id")
    abstract suspend fun deletePlaylist(id: Long)

    @Query("DELETE FROM playlist_entries WHERE playlistId = :id")
    abstract suspend fun clearEntries(id: Long)

    @Insert
    abstract suspend fun insertEntries(e: List<PlaylistEntry>)

    @Query("SELECT COUNT(*) FROM playlist_entries WHERE playlistId = :id")
    abstract suspend fun countEntries(id: Long): Int

    @Transaction
    open suspend fun replaceEntries(id: Long, uris: List<String>) {
        clearEntries(id)
        insertEntries(uris.mapIndexed { i, u -> PlaylistEntry(0, id, u, i) })
    }

    @Transaction
    open suspend fun appendEntries(id: Long, uris: List<String>) {
        val start = countEntries(id)
        insertEntries(uris.mapIndexed { i, u -> PlaylistEntry(0, id, u, start + i) })
    }

    @Transaction
    open suspend fun removePlaylist(id: Long) {
        clearEntries(id)
        deletePlaylist(id)
    }
}

@Database(
    entities = [SongEntity::class, PlaylistEntity::class, PlaylistEntry::class],
    version = 1,
    exportSchema = false,
)
abstract class XyzDb : RoomDatabase() {
    abstract fun songs(): SongDao
    abstract fun playlists(): PlaylistDao
}
