package com.xyz.player.lyrics

data class LyricLine(val timeMs: Long, val text: String)
data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

object LrcParser {
    private val stamp = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val offsetTag = Regex("""^\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)
    private val metaTag = Regex("""^\[[a-zA-Z#]+:.*]\s*$""")
    private val wordStamp = Regex("""<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>""")

    fun parse(text: String): Lyrics {
        var offset = 0L
        val timed = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        for (raw in text.lines()) {
            val line = raw.trim().trimStart('\uFEFF')
            if (line.isEmpty()) continue
            val om = offsetTag.find(line)
            if (om != null) { offset = om.groupValues[1].toLongOrNull() ?: 0L; continue }
            val stamps = leadingStamps(line)
            if (stamps.isEmpty()) {
                if (metaTag.matches(line)) continue
                plain += wordStamp.replace(line, "").trim()
                continue
            }
            val body = wordStamp.replace(line.substring(stamps.last().second), "").trim()
            for ((ms, _) in stamps) timed += LyricLine(ms, body)
        }
        if (timed.isNotEmpty()) {
            val sorted = timed.map { it.copy(timeMs = (it.timeMs - offset).coerceAtLeast(0L)) }.sortedBy { it.timeMs }
            return Lyrics(sorted, true)
        }
        return Lyrics(plain.map { LyricLine(0L, it) }, false)
    }

    /** Timestamps at the very beginning of the line: list of (timeMs, endIndexExclusive). */
    private fun leadingStamps(line: String): List<Pair<Long, Int>> {
        val out = ArrayList<Pair<Long, Int>>()
        var pos = 0
        while (pos < line.length) {
            val m = stamp.matchAt(line, pos) ?: break
            val mm = m.groupValues[1].toLong()
            val ss = m.groupValues[2].toLong()
            val frac = m.groupValues[3]
            val fracMs = when (frac.length) { 0 -> 0L; 1 -> frac.toLong() * 100; 2 -> frac.toLong() * 10; else -> frac.take(3).toLong() }
            out += (mm * 60_000 + ss * 1000 + fracMs) to (m.range.last + 1)
            pos = m.range.last + 1
        }
        return out
    }

    /** Index of the last line whose time is <= positionMs, or -1 when before the first line. */
    fun indexAt(lines: List<LyricLine>, positionMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= positionMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }
}
