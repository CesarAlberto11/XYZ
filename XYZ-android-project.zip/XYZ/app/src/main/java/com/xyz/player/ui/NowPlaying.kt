package com.xyz.player.ui

import android.media.AudioManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.xyz.player.R
import com.xyz.player.audio.PlaybackRuntime
import com.xyz.player.audio.SleepTimer
import com.xyz.player.audio.TechInfo
import com.xyz.player.data.AppSettings
import com.xyz.player.lyrics.LrcParser
import com.xyz.player.lyrics.Lyrics
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max

@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit, onOpenEffects: () -> Unit, onOpenOutput: () -> Unit) {
    val st by vm.player.collectAsStateWithLifecycle()
    val song by vm.currentSong.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val pos by vm.position.collectAsStateWithLifecycle()
    val sleep by SleepTimer.state.collectAsStateWithLifecycle()
    val tech by PlaybackRuntime.tech.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    val wide = LocalConfiguration.current.screenWidthDp >= 840
    var tab by rememberSaveable { mutableIntStateOf(0) } // 0 cover, 1 lyrics, 2 queue
    var sheet by remember { mutableIntStateOf(0) } // 0 none, 1 speed, 2 sleep, 3 info
    val art by rememberArt(st.mediaId, 32)
    val dur = if (st.durationMs > 0) st.durationMs else song?.durationMs ?: 0L

    Box(Modifier.fillMaxSize().background(cs.background)) {
        art?.let { Image(it, null, Modifier.fillMaxSize().alpha(0.6f), contentScale = ContentScale.Crop, filterQuality = FilterQuality.Low) }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(cs.background.copy(alpha = 0.30f), cs.background.copy(alpha = 0.88f), cs.background))))

        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, stringResource(R.string.cd_close_player), modifier = Modifier.size(30.dp)) }
                Text(stringResource(R.string.now_playing), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleSmall, color = cs.onSurfaceVariant)
                Spacer(Modifier.size(48.dp))
            }
            if (wide) {
                Row(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                    Column(Modifier.weight(1f)) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CoverPane(st, true) }
                        PlayerControlsBlock(vm, st, song, settings, tech, pos, dur, sleep, { sheet = it }, onOpenEffects, onOpenOutput)
                    }
                    Column(Modifier.weight(1f)) {
                        PaneChips(if (tab == 2) 2 else 1, listOf(1, 2)) { tab = it }
                        Box(Modifier.weight(1f)) { if (tab == 2) QueuePane(vm, st) else LyricsPane(vm, st, settings, pos) }
                    }
                }
            } else {
                PaneChips(tab, listOf(0, 1, 2)) { tab = it }
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                    when (tab) {
                        0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CoverPane(st, true) }
                        1 -> LyricsPane(vm, st, settings, pos)
                        else -> QueuePane(vm, st)
                    }
                }
                PlayerControlsBlock(vm, st, song, settings, tech, pos, dur, sleep, { sheet = it }, onOpenEffects, onOpenOutput)
            }
        }
    }
    when (sheet) {
        1 -> SpeedSheet(vm, st, settings) { sheet = 0 }
        2 -> SleepSheet { sheet = 0 }
        3 -> InfoSheet(song, tech, dur) { sheet = 0 }
    }
}

@Composable
private fun PaneChips(selected: Int, ids: List<Int>, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ids.forEach { id ->
            FilterChip(
                selected = selected == id, onClick = { onSelect(id) },
                label = { Text(stringResource(when (id) { 0 -> R.string.pane_cover; 1 -> R.string.pane_lyrics; else -> R.string.pane_queue })) },
            )
        }
    }
}

@Composable
private fun CoverPane(st: PlayerState, showSpectrum: Boolean) {
    val reduce = LocalReduceMotion.current
    val scale by animateFloatAsState(if (st.isPlaying || reduce) 1f else 0.92f, if (reduce) snap() else tween(450), label = "cover")
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        val shape = RoundedCornerShape(28.dp)
        ArtImage(
            st.mediaId,
            Modifier.fillMaxWidth(0.84f).widthIn(max = 460.dp).aspectRatio(1f)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .shadow(28.dp, shape),
            px = 640, shape = shape,
        )
        if (showSpectrum) SpectrumBars(st.isPlaying, Modifier.fillMaxWidth(0.84f).widthIn(max = 460.dp).padding(top = 24.dp).height(40.dp))
    }
}

// ---------------------------------------------------------------- controls block

@Composable
private fun PlayerControlsBlock(
    vm: MainViewModel, st: PlayerState, song: com.xyz.player.data.SongEntity?, settings: AppSettings,
    tech: TechInfo?, pos: Long, dur: Long, sleep: SleepTimer.State, openSheet: (Int) -> Unit,
    onOpenEffects: () -> Unit, onOpenOutput: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val reduce = LocalReduceMotion.current
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: st.title, style = MaterialTheme.typography.headlineSmall, maxLines = 1, modifier = Modifier.basicMarquee())
                Text(
                    artistLabel(song?.artist ?: st.artist) + (song?.album?.takeIf { it.isNotBlank() }?.let { "  –  $it" } ?: ""),
                    style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                techBadge(tech)?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = cs.primary, modifier = Modifier.padding(top = 2.dp)) }
            }
            IconButton(onClick = { song?.let { vm.toggleFavorite(listOf(it.uri), !it.favorite) } }, enabled = song != null) {
                Icon(
                    if (song?.favorite == true) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    stringResource(if (song?.favorite == true) R.string.remove_favorite else R.string.add_favorite),
                    tint = if (song?.favorite == true) cs.primary else cs.onSurfaceVariant,
                )
            }
        }
        SeekBar(pos, dur) { vm.seekTo(it) }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::toggleShuffle) {
                Icon(Icons.Rounded.Shuffle, stringResource(R.string.shuffle), tint = if (st.shuffle) cs.primary else cs.onSurfaceVariant)
            }
            IconButton(onClick = vm::previous, Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipPrevious, stringResource(R.string.cd_previous), Modifier.size(36.dp)) }
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val s by animateFloatAsState(if (pressed && !reduce) 0.9f else 1f, label = "press")
            FilledIconButton(onClick = vm::togglePlay, interactionSource = src, modifier = Modifier.size(76.dp).graphicsLayer { scaleX = s; scaleY = s }) {
                Icon(if (st.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, stringResource(if (st.isPlaying) R.string.cd_pause else R.string.cd_play), Modifier.size(42.dp))
            }
            IconButton(onClick = vm::next, Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipNext, stringResource(R.string.cd_next), Modifier.size(36.dp)) }
            IconButton(onClick = vm::cycleRepeat) {
                Icon(
                    if (st.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    stringResource(R.string.repeat), tint = if (st.repeat != Player.REPEAT_MODE_OFF) cs.primary else cs.onSurfaceVariant,
                )
            }
        }
        val now by produceState(System.currentTimeMillis(), sleep) { while (sleep.active) { value = System.currentTimeMillis(); delay(1000) } }
        val sleepLabel = when {
            sleep.untilEndOfTrack -> stringResource(R.string.sleep_end_short)
            sleep.endAtMs > 0 -> formatTime((sleep.endAtMs - now).coerceAtLeast(0))
            else -> stringResource(R.string.sleep)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
            QuickAction(Icons.Rounded.Speed, "%.2fx".format(st.speed), abs(st.speed - 1f) > 0.01f || st.pitch != 1f, Modifier.weight(1f)) { openSheet(1) }
            QuickAction(Icons.Rounded.Timer, sleepLabel, sleep.active, Modifier.weight(1f)) { openSheet(2) }
            QuickAction(Icons.Rounded.Tune, stringResource(R.string.nav_effects), false, Modifier.weight(1f), onOpenEffects)
            QuickAction(Icons.Rounded.Headphones, stringResource(R.string.output), false, Modifier.weight(1f), onOpenOutput)
            QuickAction(Icons.Rounded.Info, stringResource(R.string.info), false, Modifier.weight(1f)) { openSheet(3) }
        }
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 6.dp)
            .semantics(mergeDescendants = true) { contentDescription = label },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = if (active) cs.primary else cs.onSurfaceVariant)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = if (active) cs.primary else cs.onSurfaceVariant)
    }
}

@Composable
private fun SeekBar(pos: Long, dur: Long, onSeek: (Long) -> Unit) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val maxV = max(1f, dur.toFloat())
    val desc = stringResource(R.string.cd_seek)
    Column(Modifier.padding(horizontal = 24.dp)) {
        Slider(
            value = (drag ?: pos.toFloat()).coerceIn(0f, maxV),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { onSeek(it.toLong()) }; drag = null },
            valueRange = 0f..maxV,
            modifier = Modifier.semantics { contentDescription = desc },
        )
        Row(Modifier.fillMaxWidth()) {
            Text(formatTime((drag ?: pos.toFloat()).toLong()), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(formatTime(dur), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------- lyrics

@Composable
private fun LyricsPane(vm: MainViewModel, st: PlayerState, settings: AppSettings, pos: Long) {
    val ly by vm.lyrics.collectAsStateWithLifecycle()
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importLyrics(u) }
    val lyr = ly.lyrics
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (lyr == null || lyr.lines.isEmpty()) {
                EmptyState(
                    Icons.Rounded.Subtitles, stringResource(R.string.no_lyrics_title), stringResource(R.string.no_lyrics_body),
                    action = { FilledTonalButton(onClick = { importer.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.import_lrc)) } },
                )
            } else LyricsList(vm, lyr, settings, pos, st.mediaId)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.setLyricsSize((settings.lyricsSize - 2).coerceAtLeast(16)) }) { Text("A−") }
            TextButton(onClick = { vm.setLyricsSize((settings.lyricsSize + 2).coerceAtMost(40)) }) { Text("A+") }
            TextButton(onClick = { vm.setLyricsOffset(settings.lyricsOffsetMs - 500) }) { Text("−0.5 s") }
            Text("%+.1f s".format(settings.lyricsOffsetMs / 1000f), style = MaterialTheme.typography.labelMedium, modifier = Modifier.clickable { vm.setLyricsOffset(0) })
            TextButton(onClick = { vm.setLyricsOffset(settings.lyricsOffsetMs + 500) }) { Text("+0.5 s") }
            IconButton(onClick = { importer.launch(arrayOf("*/*")) }) { Icon(Icons.Rounded.UploadFile, stringResource(R.string.import_lrc)) }
            if (ly.source == 1) IconButton(onClick = vm::removeLyrics) { Icon(Icons.Rounded.Delete, stringResource(R.string.remove_lyrics)) }
        }
        if (lyr != null && lyr.lines.isNotEmpty()) {
            Text(
                stringResource(
                    when {
                        !lyr.synced -> R.string.lyrics_unsynced
                        ly.source == 2 -> R.string.lyrics_embedded
                        else -> R.string.lyrics_imported
                    },
                ),
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 16.dp, bottom = 2.dp),
            )
        }
    }
}

@Composable
private fun LyricsList(vm: MainViewModel, lyr: Lyrics, settings: AppSettings, pos: Long, mediaId: String?) {
    val reduce = LocalReduceMotion.current
    val listState = rememberLazyListState()
    val adjusted = pos + settings.lyricsOffsetMs
    val current = if (lyr.synced) LrcParser.indexAt(lyr.lines, adjusted) else -1
    var autoScrolling by remember { mutableStateOf(false) }
    var lastManual by remember { mutableLongStateOf(0L) }

    LaunchedEffect(mediaId) { listState.scrollToItem(0); lastManual = 0L }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { sc -> if (sc && !autoScrolling) lastManual = SystemClock.elapsedRealtime() }
    }
    LaunchedEffect(current, lyr) {
        if (current >= 0 && SystemClock.elapsedRealtime() - lastManual > 3500) {
            autoScrolling = true
            try {
                val off = -(listState.layoutInfo.viewportSize.height / 3)
                if (reduce) listState.scrollToItem(current, off) else listState.animateScrollToItem(current, off)
            } finally { autoScrolling = false }
        }
    }
    LazyColumn(state = listState, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 160.dp), modifier = Modifier.fillMaxSize()) {
        itemsIndexed(lyr.lines) { i, line ->
            LyricLineItem(
                text = line.text,
                distance = if (current < 0) i + 1 else abs(i - current),
                synced = lyr.synced, sizeSp = settings.lyricsSize, reduce = reduce,
                onClick = if (lyr.synced) ({ vm.seekTo(line.timeMs - settings.lyricsOffsetMs) }) else null,
            )
        }
    }
}

@Composable
private fun LyricLineItem(text: String, distance: Int, synced: Boolean, sizeSp: Int, reduce: Boolean, onClick: (() -> Unit)?) {
    val targetAlpha = if (!synced) 0.92f else when (distance) { 0 -> 1f; 1 -> 0.62f; 2 -> 0.44f; 3 -> 0.32f; else -> 0.22f }
    val targetBlur = if (!synced) 0f else when (distance) { 0 -> 0f; 1 -> 1.2f; 2 -> 2.6f; 3 -> 4f; else -> 5.5f }
    val spec = if (reduce) snap<Float>() else tween<Float>(380)
    val a by animateFloatAsState(targetAlpha, spec, label = "lyricAlpha")
    val b by animateFloatAsState(targetBlur, spec, label = "lyricBlur")
    val sc by animateFloatAsState(if (synced && distance != 0) 0.94f else 1f, spec, label = "lyricScale")
    Text(
        text.ifBlank { "♪" },
        modifier = Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 10.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc; alpha = a; transformOrigin = TransformOrigin(0f, 0.5f) }
            .blur(b.dp, BlurredEdgeTreatment.Unbounded),
        fontSize = sizeSp.sp, lineHeight = (sizeSp * 1.25f).sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground,
    )
}

// ---------------------------------------------------------------- queue

@Composable
private fun QueuePane(vm: MainViewModel, st: PlayerState) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.queue_title, st.queue.size), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = vm::clearQueue, enabled = st.queue.isNotEmpty()) {
                Icon(Icons.Rounded.DeleteSweep, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.clear_queue))
            }
        }
        if (st.queue.isEmpty()) EmptyState(Icons.Rounded.Close, stringResource(R.string.queue_empty_title), stringResource(R.string.queue_empty_body))
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(st.queue) { i, q ->
                val cur = i == st.index
                Row(
                    Modifier.fillMaxWidth().clickable { vm.playQueueItem(i) }.padding(start = 12.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ArtImage(q.mediaId, Modifier.size(44.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(q.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (cur) cs.primary else cs.onBackground, fontWeight = if (cur) FontWeight.Bold else FontWeight.Medium)
                        Text(artistLabel(q.artist), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    IconButton(onClick = { vm.moveQueue(i, i - 1) }, enabled = i > 0) { Icon(Icons.Rounded.ArrowUpward, stringResource(R.string.move_up)) }
                    IconButton(onClick = { vm.moveQueue(i, i + 1) }, enabled = i < st.queue.lastIndex) { Icon(Icons.Rounded.ArrowDownward, stringResource(R.string.move_down)) }
                    IconButton(onClick = { vm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, stringResource(R.string.remove_from_queue)) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- sheets

@Composable
private fun SpeedSheet(vm: MainViewModel, st: PlayerState, settings: AppSettings, onDismiss: () -> Unit) {
    var v by remember { mutableFloatStateOf(st.speed) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.speed), style = MaterialTheme.typography.titleLarge)
            Text("%.2fx".format(v), style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.primary)
            Slider(
                value = v, onValueChange = { v = it; vm.setSpeed(it, settings.pitchLinked, persist = false) },
                onValueChangeFinished = { vm.setSpeed(v, settings.pitchLinked) },
                valueRange = 0.5f..2f, steps = 29,
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { p ->
                    FilterChip(selected = abs(v - p) < 0.01f, onClick = { v = p; vm.setSpeed(p, settings.pitchLinked) }, label = { Text("${p}x") })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(onClick = { v = 0.85f; vm.setSpeed(0.85f, true) }) { Text(stringResource(R.string.slowed_mode)) }
                OutlinedButton(onClick = { v = 1f; vm.setSpeed(1f, false) }) { Text(stringResource(R.string.reset)) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.link_pitch), fontWeight = FontWeight.Medium)
                    Text(stringResource(R.string.link_pitch_desc), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = settings.pitchLinked, onCheckedChange = { vm.setSpeed(v, it) })
            }
        }
    }
}

@Composable
private fun SleepSheet(onDismiss: () -> Unit) {
    val sleep by SleepTimer.state.collectAsStateWithLifecycle()
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(bottom = 32.dp)) {
            Text(stringResource(R.string.sleep_timer), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
            listOf(15, 30, 45, 60, 90).forEach { m ->
                ListItem(
                    headlineContent = { Text(stringResource(R.string.n_minutes, m)) },
                    colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    modifier = Modifier.clickable { SleepTimer.startMinutes(m); onDismiss() },
                )
            }
            ListItem(
                headlineContent = { Text(stringResource(R.string.sleep_end_of_song)) },
                colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                modifier = Modifier.clickable { SleepTimer.startEndOfTrack(); onDismiss() },
            )
            if (sleep.active) {
                HorizontalDivider()
                ListItem(
                    headlineContent = { Text(stringResource(R.string.sleep_cancel), color = MaterialTheme.colorScheme.error) },
                    colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    modifier = Modifier.clickable { SleepTimer.cancel(); onDismiss() },
                )
            }
        }
    }
}

fun mimeLabel(mime: String?): String = when {
    mime == null -> "?"
    mime.contains("mpeg") -> "MP3"
    mime.contains("flac") -> "FLAC"
    mime.contains("mp4a") || mime.contains("aac") -> "AAC"
    mime.contains("vorbis") -> "Vorbis"
    mime.contains("opus") -> "Opus"
    mime.contains("raw") || mime.contains("wav") -> "PCM/WAV"
    mime.contains("alac") -> "ALAC"
    else -> mime.substringAfter('/').uppercase()
}

@Composable
fun techBadge(t: TechInfo?): String? {
    if (t == null) return null
    val parts = ArrayList<String>()
    parts += mimeLabel(t.mime)
    if (t.sampleRate > 0) parts += "%.1f kHz".format(t.sampleRate / 1000f)
    t.pcmBits?.let { parts += "$it-bit" }
    if (t.bitrate > 0) parts += "${t.bitrate / 1000} kbps"
    return parts.joinToString("  ·  ")
}

@Composable
private fun InfoSheet(song: com.xyz.player.data.SongEntity?, t: TechInfo?, dur: Long, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val rg by PlaybackRuntime.replayGainDb.collectAsStateWithLifecycle()
    val am = remember { ctx.getSystemService(AudioManager::class.java) }
    val outRate = remember { am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) }
    val outBuf = remember { am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER) }
    val device = remember { describeActiveOutput(ctx) }
    val na = stringResource(R.string.not_available)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.track_info), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.info_file), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
            InfoRow(stringResource(R.string.format), t?.let { mimeLabel(it.mime) + (it.codecs?.let { c -> " ($c)" } ?: "") } ?: na)
            InfoRow(stringResource(R.string.sample_rate), t?.sampleRate?.takeIf { it > 0 }?.let { "%.1f kHz".format(it / 1000f) } ?: na)
            InfoRow(stringResource(R.string.bit_depth), t?.pcmBits?.let { "$it-bit" } ?: na)
            InfoRow(stringResource(R.string.channels), t?.channels?.takeIf { it > 0 }?.toString() ?: na)
            InfoRow(stringResource(R.string.bitrate), t?.bitrate?.takeIf { it > 0 }?.let { "${it / 1000} kbps" } ?: na)
            InfoRow(stringResource(R.string.duration), if (dur > 0) formatTime(dur) else na)
            InfoRow(stringResource(R.string.genre), song?.genre?.ifBlank { null } ?: na)
            InfoRow(stringResource(R.string.year), song?.year?.takeIf { it > 0 }?.toString() ?: na)
            InfoRow(stringResource(R.string.replaygain), rg?.let { "%+.2f dB".format(it) } ?: na)
            Text(stringResource(R.string.info_output), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp))
            InfoRow(stringResource(R.string.active_device), device ?: na)
            InfoRow(stringResource(R.string.mixer_rate), outRate?.let { "$it Hz" } ?: na)
            InfoRow(stringResource(R.string.mixer_buffer), outBuf?.let { "$it frames" } ?: na)
            Text(stringResource(R.string.info_disclaimer), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, Modifier.weight(0.45f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(value, Modifier.weight(0.55f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
