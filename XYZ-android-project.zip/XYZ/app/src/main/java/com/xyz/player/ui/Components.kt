package com.xyz.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xyz.player.R
import com.xyz.player.audio.AudioEngine
import com.xyz.player.data.ArtLoader
import com.xyz.player.data.SongEntity
import kotlinx.coroutines.withContext
import kotlin.math.max

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

data class MenuAction(val labelRes: Int, val onClick: () -> Unit)

@Composable fun artistLabel(a: String): String = a.ifBlank { stringResource(R.string.unknown_artist) }
@Composable fun albumLabel(a: String): String = a.ifBlank { stringResource(R.string.unknown_album) }

@Composable
fun rememberArt(uri: String?, px: Int): State<ImageBitmap?> {
    val ctx = LocalContext.current.applicationContext
    return produceState<ImageBitmap?>(null, uri, px) {
        if (uri == null) { value = null; return@produceState }
        value = ArtLoader.peek(uri, px)?.asImageBitmap()
        if (value == null) value = withContext(ArtLoader.dispatcher) { ArtLoader.load(ctx, uri, px)?.asImageBitmap() }
    }
}

@Composable
fun ArtImage(uri: String?, modifier: Modifier = Modifier, px: Int = 128, shape: Shape = RoundedCornerShape(10.dp)) {
    val art by rememberArt(uri, px)
    val cs = MaterialTheme.colorScheme
    Box(
        modifier.clip(shape).background(Brush.linearGradient(listOf(cs.surfaceVariant, cs.primary.copy(alpha = 0.28f)))),
        contentAlignment = Alignment.Center,
    ) {
        val b = art
        if (b != null) Image(b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = cs.onSurfaceVariant.copy(alpha = 0.6f))
    }
}

@Composable
fun SongMenu(actions: List<MenuAction>) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.MoreVert, stringResource(R.string.cd_more)) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            actions.forEach { a -> DropdownMenuItem(text = { Text(stringResource(a.labelRes)) }, onClick = { open = false; a.onClick() }) }
        }
    }
}

@Composable
fun SongRow(
    song: SongEntity,
    isCurrent: Boolean,
    isPlaying: Boolean,
    selected: Boolean,
    selecting: Boolean,
    menu: List<MenuAction>,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val artist = artistLabel(song.artist)
    Row(
        modifier
            .fillMaxWidth()
            .background(if (selected) cs.primaryContainer.copy(alpha = 0.55f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = if (selecting) 16.dp else 4.dp)
            .semantics(mergeDescendants = true) { contentDescription = "${song.title}, $artist" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(contentAlignment = Alignment.Center) {
            ArtImage(song.uri, Modifier.size(48.dp))
            if (selected) Box(Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(cs.primary.copy(alpha = 0.75f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Check, null, tint = cs.onPrimary)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium, color = if (isCurrent) cs.primary else cs.onSurface)
            Text(artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (isCurrent && isPlaying) Icon(Icons.Rounded.GraphicEq, null, tint = cs.primary, modifier = Modifier.padding(horizontal = 6.dp).size(20.dp))
        Text(formatTime(song.durationMs), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp))
        if (!selecting) SongMenu(menu)
    }
}

@Composable
fun SongCard(
    song: SongEntity, isCurrent: Boolean, selected: Boolean, selecting: Boolean, menu: List<MenuAction>,
    onClick: () -> Unit, onLongClick: () -> Unit, modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box {
            ArtImage(song.uri, Modifier.fillMaxWidth().aspectRatio(1f), px = 320, shape = RoundedCornerShape(16.dp))
            if (selected) Box(Modifier.matchParent().background(cs.primary.copy(alpha = 0.55f), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(36.dp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(top = 6.dp)) {
                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium, color = if (isCurrent) cs.primary else cs.onSurface)
                Text(artistLabel(song.artist), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (!selecting) SongMenu(menu)
        }
    }
}

private fun Modifier.matchParent(): Modifier = this.then(Modifier.fillMaxSize())

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleLarge, modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp))
}

@Composable
fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
        }
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        action?.invoke()
    }
}

@Composable
fun PlayShuffleHeader(songs: List<SongEntity>, vm: MainViewModel, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilledTonalButton(onClick = { vm.playSongs(songs, 0) }, enabled = songs.isNotEmpty(), modifier = Modifier.weight(1f)) {
            Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.play))
        }
        OutlinedButton(onClick = { vm.playSongs(songs.shuffled(), 0, true) }, enabled = songs.isNotEmpty(), modifier = Modifier.weight(1f)) {
            Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text(stringResource(R.string.shuffle))
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onExpand: () -> Unit) {
    val st by vm.player.collectAsStateWithLifecycle()
    val pos by vm.position.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme
    val dur = st.durationMs
    Surface(
        onClick = onExpand,
        color = cs.surfaceContainerHigh,
        shape = RoundedCornerShape(28.dp),
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).pointerInput(Unit) {
            var total = 0f
            detectVerticalDragGestures(onDragStart = { total = 0f }, onDragEnd = { if (total < -50f) onExpand() }) { _, d -> total += d }
        },
    ) {
        Column {
            Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                ArtImage(st.mediaId, Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(st.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text(artistLabel(st.artist), maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = vm::previous) { Icon(Icons.Rounded.SkipPrevious, stringResource(R.string.cd_previous)) }
                IconButton(onClick = vm::togglePlay) {
                    Icon(if (st.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        stringResource(if (st.isPlaying) R.string.cd_pause else R.string.cd_play), modifier = Modifier.size(30.dp))
                }
                IconButton(onClick = vm::next) { Icon(Icons.Rounded.SkipNext, stringResource(R.string.cd_next)) }
            }
            LinearProgressIndicator(
                progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth().height(2.dp), trackColor = Color.Transparent,
            )
        }
    }
}

/** Real spectrum from the DSP chain (FFT of the audio being played). Static when reduced motion is on. */
@Composable
fun SpectrumBars(active: Boolean, modifier: Modifier = Modifier, bars: Int = 32) {
    val on = active && !LocalReduceMotion.current
    var frame by remember { mutableIntStateOf(0) }
    DisposableEffect(on) {
        AudioEngine.core.spectrumEnabled = on
        onDispose { AudioEngine.core.spectrumEnabled = false }
    }
    LaunchedEffect(on) { if (on) while (true) androidx.compose.runtime.withFrameNanos { frame++ } }
    val brush = Brush.verticalGradient(listOf(MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.primary))
    Canvas(modifier.semantics { contentDescription = "" }) {
        val tick = frame
        if (tick < 0) return@Canvas
        val sp = AudioEngine.core.spectrum
        val n = minOf(bars, sp.size)
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val level = if (on) sp[i * sp.size / n] else 0f
            val h = max(3.dp.toPx(), level * size.height)
            drawRoundRect(brush, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(bw / 2))
        }
    }
}

@Composable
fun TextPromptDialog(titleRes: Int, initial: String, confirmRes: Int, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(titleRes)) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text(stringResource(R.string.name)) }) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) { onConfirm(text.trim()); onDismiss() } }) { Text(stringResource(confirmRes)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun ConfirmDialog(titleRes: Int, bodyRes: Int, confirmRes: Int, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(titleRes)) },
        text = { Text(stringResource(bodyRes)) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(stringResource(confirmRes)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun PlaylistPickerDialog(vm: MainViewModel, uris: List<String>, onDone: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(stringResource(R.string.add_to_playlist)) },
        text = {
            Column {
                if (playlists.isEmpty() && !creating) Text(stringResource(R.string.no_playlists_yet))
                LazyColumn(Modifier.heightIn(max = 280.dp)) {
                    items(playlists) { p ->
                        ListItem(
                            headlineContent = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(stringResource(R.string.n_songs, p.songs.size)) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { vm.addToPlaylist(p.id, uris); onDone() },
                        )
                    }
                }
                if (creating) OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.name)) })
            }
        },
        confirmButton = {
            if (creating) TextButton(onClick = { if (name.isNotBlank()) { vm.createPlaylist(name, uris); onDone() } }) { Text(stringResource(R.string.create)) }
            else TextButton(onClick = { creating = true }) { Text(stringResource(R.string.new_playlist)) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun EditMetaDialog(song: SongEntity, vm: MainViewModel, onDone: () -> Unit) {
    var title by remember { mutableStateOf(song.title) }
    var artist by remember { mutableStateOf(song.artist) }
    var album by remember { mutableStateOf(song.album) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(stringResource(R.string.edit_info)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, singleLine = true, label = { Text(stringResource(R.string.title)) })
                OutlinedTextField(artist, { artist = it }, singleLine = true, label = { Text(stringResource(R.string.artist)) })
                OutlinedTextField(album, { album = it }, singleLine = true, label = { Text(stringResource(R.string.album)) })
                Text(stringResource(R.string.edit_info_note), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = { vm.editMeta(song.uri, title.trim(), artist.trim(), album.trim()); onDone() }) { Text(stringResource(R.string.save)) } },
        dismissButton = { TextButton(onClick = onDone) { Text(stringResource(R.string.cancel)) } },
    )
}
