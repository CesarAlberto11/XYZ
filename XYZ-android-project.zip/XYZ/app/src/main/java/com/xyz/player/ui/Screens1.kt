package com.xyz.player.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.xyz.player.R
import com.xyz.player.data.AlbumItem
import com.xyz.player.data.ArtistItem
import com.xyz.player.data.FolderItem
import com.xyz.player.data.SongEntity
import kotlinx.coroutines.delay

// ------------------------------------------------------------------ shared bits

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null, actions: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(start = if (onBack == null) 16.dp else 4.dp, end = 4.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.cd_back)) }
        Text(title, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

@Composable
fun EntityRow(artUri: String?, title: String, subtitle: String, round: Boolean = false, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    ListItem(
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium) },
        supportingContent = { Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingContent = { ArtImage(artUri, Modifier.size(52.dp), px = 128, shape = if (round) CircleShape else RoundedCornerShape(12.dp)) },
        trailingContent = trailing,
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
private fun StripItem(song: SongEntity, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).clickable(onClick = onClick)) {
        ArtImage(song.uri, Modifier.size(140.dp), px = 300, shape = RoundedCornerShape(16.dp))
        Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
        Text(artistLabel(song.artist), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SongStrip(titleRes: Int, songs: List<SongEntity>, vm: MainViewModel) {
    if (songs.isEmpty()) return
    Column {
        SectionTitle(stringResource(titleRes))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(songs.size) { i -> StripItem(songs[i]) { vm.playSongs(songs, i) } }
        }
    }
}

// ------------------------------------------------------------------ Home

@Composable
fun HomeScreen(vm: MainViewModel, nav: NavController) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val scan by vm.scan.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val mostPlayed by vm.mostPlayed.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val recent by vm.recentlyAdded.collectAsStateWithLifecycle()

    var granted by remember { mutableStateOf(vm.repo.hasAudioPermission()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = vm.repo.hasAudioPermission() }
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = vm.repo.hasAudioPermission()
        if (granted) vm.startScan()
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) vm.addFolder(uri) }
    var autoScanned by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(granted) {
        if (granted && !autoScanned) {
            delay(700)
            autoScanned = true
            if (vm.songs.value.isEmpty()) vm.startScan()
        }
    }
    fun requestPerms() {
        val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(audioPerm)
        permLauncher.launch(p)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("XYZ", style = MaterialTheme.typography.headlineLarge, letterSpacing = 6.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { nav.navigate(Routes.SEARCH) }) { Icon(Icons.Rounded.Search, stringResource(R.string.search)) }
            }
            if (songs.isNotEmpty()) Text(stringResource(R.string.n_songs, songs.size), Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
        if (scan.running) item {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.scanning_found, scan.found), style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
        if (songs.isEmpty() && !scan.running) item {
            if (!granted) EmptyState(
                Icons.Rounded.LibraryMusic, stringResource(R.string.perm_title), stringResource(R.string.perm_body),
                action = {
                    Button(onClick = ::requestPerms) { Text(stringResource(R.string.grant_access)) }
                    OutlinedButton(onClick = { folderPicker.launch(null) }) { Text(stringResource(R.string.choose_folder)) }
                },
            ) else EmptyState(
                Icons.Rounded.MusicNote, stringResource(R.string.empty_library_title), stringResource(R.string.empty_library_body),
                action = {
                    Button(onClick = { vm.startScan() }) { Text(stringResource(R.string.scan_now)) }
                    OutlinedButton(onClick = { folderPicker.launch(null) }) { Text(stringResource(R.string.choose_folder)) }
                },
            )
        }
        if (songs.isNotEmpty()) {
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { vm.shuffleAll() }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.shuffle_all))
                    }
                    FilledTonalButton(onClick = { vm.playSongs(songs, 0) }, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.play_all)) }
                }
            }
            item { SongStrip(R.string.recently_played, history.take(20), vm) }
            item { SongStrip(R.string.most_played, mostPlayed.take(20), vm) }
            item { SongStrip(R.string.favorites, favorites.take(20), vm) }
            item { SongStrip(R.string.recently_added, recent.take(20), vm) }
        }
    }
}

// ------------------------------------------------------------------ Library

@Composable
fun LibraryScreen(vm: MainViewModel, nav: NavController) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val folders by vm.folders.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sort by rememberSaveable { mutableIntStateOf(0) }
    var sortOpen by remember { mutableStateOf(false) }
    val tabs = listOf(R.string.tab_songs, R.string.tab_albums, R.string.tab_artists, R.string.tab_folders, R.string.favorites, R.string.history)
    val sorted = remember(songs, sort) {
        when (sort) {
            1 -> songs.sortedBy { it.artist.lowercase() }
            2 -> songs.sortedByDescending { it.dateAdded }
            3 -> songs.sortedByDescending { it.playCount }
            else -> songs
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_library)) {
            IconButton(onClick = { nav.navigate(Routes.SEARCH) }) { Icon(Icons.Rounded.Search, stringResource(R.string.search)) }
            IconButton(onClick = { vm.setGrid(!settings.grid) }) {
                Icon(if (settings.grid) Icons.Rounded.ViewList else Icons.Rounded.GridView, stringResource(R.string.toggle_view))
            }
            if (tab == 0) Box {
                IconButton(onClick = { sortOpen = true }) { Icon(Icons.Rounded.Sort, stringResource(R.string.sort)) }
                DropdownMenu(sortOpen, { sortOpen = false }) {
                    listOf(R.string.sort_title, R.string.sort_artist, R.string.sort_added, R.string.sort_played).forEachIndexed { i, r ->
                        DropdownMenuItem(text = { Text(stringResource(r)) }, onClick = { sort = i; sortOpen = false })
                    }
                }
            }
        }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp, containerColor = Color.Transparent) {
            tabs.forEachIndexed { i, r -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(r), maxLines = 1) }) }
        }
        when (tab) {
            0 -> SongListContent(sorted, vm, grid = settings.grid, header = { PlayShuffleHeader(sorted, vm) })
            1 -> AlbumsView(albums, settings.grid, nav)
            2 -> ArtistsView(artists, nav)
            3 -> FoldersView(folders, nav)
            4 -> SongListContent(favorites, vm, grid = settings.grid, header = { PlayShuffleHeader(favorites, vm) }, emptyTitle = R.string.empty_fav_title, emptyBody = R.string.empty_fav_body)
            else -> SongListContent(history, vm, grid = settings.grid, emptyTitle = R.string.empty_history_title, emptyBody = R.string.empty_history_body)
        }
    }
}

@Composable
private fun AlbumsView(albums: List<AlbumItem>, grid: Boolean, nav: NavController) {
    if (albums.isEmpty()) { EmptyState(Icons.Rounded.MusicNote, stringResource(R.string.empty_songs_title), stringResource(R.string.empty_songs_body)); return }
    if (grid) {
        LazyVerticalGrid(GridCells.Adaptive(150.dp), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(albums.size) { i ->
                val a = albums[i]
                Column(Modifier.clickable { nav.navigate(Routes.list("album", a.name)) }) {
                    ArtImage(a.songs.first().uri, Modifier.fillMaxWidth().aspectRatio(1f), px = 320, shape = RoundedCornerShape(16.dp))
                    Text(albumLabel(a.name), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                    Text(if (a.various) stringResource(R.string.various_artists) else artistLabel(a.artist), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    } else LazyColumn {
        items(albums.size) { i ->
            val a = albums[i]
            EntityRow(a.songs.first().uri, albumLabel(a.name), (if (a.various) stringResource(R.string.various_artists) else artistLabel(a.artist)) + "  ·  " + stringResource(R.string.n_songs, a.songs.size), onClick = {
                nav.navigate(Routes.list("album", a.name))
            })
        }
    }
}

@Composable
private fun ArtistsView(artists: List<ArtistItem>, nav: NavController) {
    if (artists.isEmpty()) { EmptyState(Icons.Rounded.MusicNote, stringResource(R.string.empty_songs_title), stringResource(R.string.empty_songs_body)); return }
    LazyColumn {
        items(artists.size) { i ->
            val a = artists[i]
            EntityRow(a.songs.first().uri, artistLabel(a.name), stringResource(R.string.n_songs, a.songs.size), round = true, onClick = { nav.navigate(Routes.list("artist", a.name)) })
        }
    }
}

@Composable
private fun FoldersView(folders: List<FolderItem>, nav: NavController) {
    if (folders.isEmpty()) { EmptyState(Icons.Rounded.FolderOpen, stringResource(R.string.empty_songs_title), stringResource(R.string.empty_songs_body)); return }
    LazyColumn {
        items(folders.size) { i ->
            val f = folders[i]
            ListItem(
                headlineContent = { Text(f.name.ifBlank { stringResource(R.string.imported_files) }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium) },
                supportingContent = { Text(stringResource(R.string.n_songs, f.songs.size) + if (f.path.isNotBlank()) "  ·  ${f.path}" else "", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingContent = { Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable { nav.navigate(Routes.list("folder", f.path)) },
            )
        }
    }
}

// ------------------------------------------------------------------ detail (album / artist / folder)

@Composable
fun ListDetailScreen(vm: MainViewModel, nav: NavController, type: String, key: String) {
    val all by vm.songs.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val list = remember(all, type, key) {
        when (type) {
            "album" -> all.filter { it.album == key }.sortedWith(compareBy<SongEntity>({ it.trackNo }, { it.title.lowercase() }))
            "artist" -> all.filter { it.artist == key }
            else -> all.filter { it.folder == key }
        }
    }
    val title = when (type) {
        "album" -> albumLabel(key)
        "artist" -> artistLabel(key)
        else -> key.trimEnd('/').substringAfterLast('/').ifBlank { stringResource(R.string.imported_files) }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, onBack = { nav.popBackStack() })
        SongListContent(list, vm, grid = settings.grid, header = {
            Column {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    ArtImage(list.firstOrNull()?.uri, Modifier.size(96.dp), px = 256, shape = RoundedCornerShape(18.dp))
                    Column(Modifier.padding(start = 16.dp)) {
                        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(stringResource(R.string.n_songs, list.size), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(formatTime(list.sumOf { it.durationMs }), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
                PlayShuffleHeader(list, vm)
            }
        })
    }
}

// ------------------------------------------------------------------ Playlists

@Composable
fun PlaylistsScreen(vm: MainViewModel, nav: NavController) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Long?>(null) }
    var deleting by remember { mutableStateOf<Long?>(null) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(stringResource(R.string.nav_playlists))
            if (playlists.isEmpty()) EmptyState(Icons.Rounded.PlaylistPlay, stringResource(R.string.empty_playlists_title), stringResource(R.string.empty_playlists_body))
            LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                items(playlists, key = { it.id }) { p ->
                    var menu by remember { mutableStateOf(false) }
                    EntityRow(p.songs.firstOrNull()?.uri, p.name, stringResource(R.string.n_songs, p.songs.size), onClick = { nav.navigate(Routes.playlist(p.id)) }) {
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.Edit, stringResource(R.string.cd_more)) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { menu = false; renaming = p.id })
                                DropdownMenuItem(text = { Text(stringResource(R.string.delete)) }, onClick = { menu = false; deleting = p.id })
                            }
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Rounded.Add, null) },
            text = { Text(stringResource(R.string.new_playlist)) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }
    if (creating) TextPromptDialog(R.string.new_playlist, "", R.string.create, { vm.createPlaylist(it) }) { creating = false }
    renaming?.let { id -> TextPromptDialog(R.string.rename, playlists.firstOrNull { it.id == id }?.name.orEmpty(), R.string.save, { vm.renamePlaylist(id, it) }) { renaming = null } }
    deleting?.let { id -> ConfirmDialog(R.string.delete_playlist_title, R.string.delete_playlist_body, R.string.delete, { vm.deletePlaylist(id) }) { deleting = null } }
}

@Composable
fun PlaylistDetailScreen(vm: MainViewModel, nav: NavController, id: Long) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val pl = playlists.firstOrNull { it.id == id }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    if (pl == null) {
        Column(Modifier.fillMaxSize()) { ScreenHeader("", onBack = { nav.popBackStack() }) }
        return
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(pl.name, onBack = { nav.popBackStack() }) {
            IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, stringResource(R.string.rename)) }
            IconButton(onClick = { deleting = true }) { Icon(Icons.Rounded.Delete, stringResource(R.string.delete)) }
        }
        SongListContent(
            pl.songs, vm, grid = false,
            extras = listOf(
                RowExtra(R.string.remove_from_playlist) { vm.removeFromPlaylist(pl, it) },
                RowExtra(R.string.move_up) { vm.movePlaylistItem(pl, it, it - 1) },
                RowExtra(R.string.move_down) { vm.movePlaylistItem(pl, it, it + 1) },
            ),
            header = { PlayShuffleHeader(pl.songs, vm) },
            emptyTitle = R.string.empty_playlist_title, emptyBody = R.string.empty_playlist_body,
        )
    }
    if (renaming) TextPromptDialog(R.string.rename, pl.name, R.string.save, { vm.renamePlaylist(pl.id, it) }) { renaming = false }
    if (deleting) ConfirmDialog(R.string.delete_playlist_title, R.string.delete_playlist_body, R.string.delete, { vm.deletePlaylist(pl.id); nav.popBackStack() }) { deleting = false }
}

// ------------------------------------------------------------------ Search

@Composable
fun SearchScreen(vm: MainViewModel, nav: NavController) {
    val q by vm.query.collectAsStateWithLifecycle()
    val res by vm.search.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.cd_back)) }
            OutlinedTextField(
                q, { vm.query.value = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(),
                modifier = Modifier.weight(1f).focusRequester(focus),
                shape = RoundedCornerShape(28.dp),
            )
        }
        if (q.isBlank()) EmptyState(Icons.Rounded.Search, stringResource(R.string.search), stringResource(R.string.search_prompt))
        else if (res.isEmpty) EmptyState(Icons.Rounded.Search, stringResource(R.string.no_results), stringResource(R.string.no_results_body))
        else SongListContent(res.songs, vm, header = {
            Column {
                if (res.artists.isNotEmpty()) {
                    SectionTitle(stringResource(R.string.tab_artists))
                    res.artists.take(4).forEach { a -> EntityRow(a.songs.first().uri, artistLabel(a.name), stringResource(R.string.n_songs, a.songs.size), round = true, onClick = { nav.navigate(Routes.list("artist", a.name)) }) }
                }
                if (res.albums.isNotEmpty()) {
                    SectionTitle(stringResource(R.string.tab_albums))
                    res.albums.take(4).forEach { a -> EntityRow(a.songs.first().uri, albumLabel(a.name), if (a.various) stringResource(R.string.various_artists) else artistLabel(a.artist), onClick = { nav.navigate(Routes.list("album", a.name)) }) }
                }
                if (res.songs.isNotEmpty()) SectionTitle(stringResource(R.string.tab_songs))
            }
        })
    }
}
