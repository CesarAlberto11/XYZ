package com.xyz.player.ui

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.xyz.player.XyzApp
import com.xyz.player.audio.AudioEngine
import com.xyz.player.audio.DspSettings
import com.xyz.player.audio.PlaybackRuntime
import com.xyz.player.data.AlbumItem
import com.xyz.player.data.AppSettings
import com.xyz.player.data.ArtistItem
import com.xyz.player.data.EqProfile
import com.xyz.player.data.FolderItem
import com.xyz.player.data.PlaylistUi
import com.xyz.player.data.ScanProgress
import com.xyz.player.data.SearchResults
import com.xyz.player.data.SongEntity
import com.xyz.player.data.normalize
import com.xyz.player.data.toAlbums
import com.xyz.player.data.toArtists
import com.xyz.player.data.toFolders
import com.xyz.player.data.toMediaItem
import com.xyz.player.lyrics.LrcParser
import com.xyz.player.lyrics.Lyrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class QueueItem(val mediaId: String, val title: String, val artist: String)

data class PlayerState(
    val connected: Boolean = false,
    val isPlaying: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val index: Int = -1,
    val queue: List<QueueItem> = emptyList(),
)

data class LyricsUi(val lyrics: Lyrics? = null, val source: Int = 0) // source: 0 none, 1 imported file, 2 embedded tag

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val xyz = app as XyzApp
    val repo = xyz.repo
    private val prefs = xyz.prefs
    private val lyricsStore = xyz.lyrics
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val _player = MutableStateFlow(PlayerState())
    val player: StateFlow<PlayerState> = _player.asStateFlow()

    val settings: StateFlow<AppSettings> = prefs.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val eqProfiles: StateFlow<List<EqProfile>> = prefs.eqProfiles.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val scan: StateFlow<ScanProgress> = repo.scan

    // ------------------------------------------------------------ library flows
    val songs: StateFlow<List<SongEntity>> = repo.songs
        .map { l -> l.sortedBy { it.title.lowercase() } }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val songMap: StateFlow<Map<String, SongEntity>> = songs.map { l -> l.associateBy { it.uri } }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    private fun <T> derived(init: T, f: (List<SongEntity>) -> T): StateFlow<T> =
        songs.map(f).flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    val albums: StateFlow<List<AlbumItem>> = derived(emptyList()) { it.toAlbums() }
    val artists: StateFlow<List<ArtistItem>> = derived(emptyList()) { it.toArtists() }
    val folders: StateFlow<List<FolderItem>> = derived(emptyList()) { it.toFolders() }
    val favorites: StateFlow<List<SongEntity>> = derived(emptyList()) { l -> l.filter { it.favorite } }
    val history: StateFlow<List<SongEntity>> = derived(emptyList()) { l -> l.filter { it.lastPlayed > 0 }.sortedByDescending { it.lastPlayed }.take(200) }
    val mostPlayed: StateFlow<List<SongEntity>> = derived(emptyList()) { l -> l.filter { it.playCount > 0 }.sortedByDescending { it.playCount }.take(30) }
    val recentlyAdded: StateFlow<List<SongEntity>> = derived(emptyList()) { l -> l.sortedByDescending { it.dateAdded }.take(30) }

    val playlists: StateFlow<List<PlaylistUi>> = combine(repo.playlists, repo.entries, songMap) { pls, entries, map ->
        val byPl = entries.groupBy { it.playlistId }
        pls.map { p -> PlaylistUi(p.id, p.name, byPl[p.id].orEmpty().sortedBy { it.position }.mapNotNull { map[it.songUri] }) }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentSong: StateFlow<SongEntity?> =
        combine(songMap, _player.map { it.mediaId }.distinctUntilChanged()) { m, id -> id?.let { m[it] } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // ------------------------------------------------------------ search
    val query = MutableStateFlow("")
    val search: StateFlow<SearchResults> = combine(query.debounce(120), songs) { q, list ->
        val n = normalize(q)
        if (n.isBlank()) SearchResults() else {
            val hits = list.filter { normalize(it.title).contains(n) || normalize(it.artist).contains(n) || normalize(it.album).contains(n) }
            SearchResults(
                songs = hits.take(100),
                albums = list.filter { normalize(it.album).contains(n) }.toAlbums().take(20),
                artists = list.filter { normalize(it.artist).contains(n) }.toArtists().take(20),
            )
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SearchResults())

    // ------------------------------------------------------------ position + lyrics
    val position: StateFlow<Long> = flow {
        while (true) { emit(controller?.currentPosition ?: 0L); delay(100) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(2000), 0L)

    private val lyricsRevision = MutableStateFlow(0)
    val lyrics: StateFlow<LyricsUi> = combine(
        _player.map { it.mediaId }.distinctUntilChanged(), PlaybackRuntime.embeddedLyrics, lyricsRevision,
    ) { id, emb, _ ->
        when {
            id == null -> LyricsUi()
            else -> {
                val imported = lyricsStore.load(id)
                if (imported != null) LyricsUi(LrcParser.parse(imported), 1)
                else if (emb != null && emb.first == id && emb.second.isNotBlank()) LyricsUi(LrcParser.parse(emb.second), 2)
                else LyricsUi()
            }
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.Eagerly, LyricsUi())

    val errors = PlaybackRuntime.errors

    // ------------------------------------------------------------ controller
    init {
        val token = SessionToken(app, ComponentName(app, com.xyz.player.playback.PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        controllerFuture = f
        f.addListener({ runCatching { f.get() }.getOrNull()?.let { onConnected(it) } }, ContextCompat.getMainExecutor(app))
    }

    private fun onConnected(c: MediaController) {
        controller = c
        c.addListener(object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) { refresh(p, events.contains(Player.EVENT_TIMELINE_CHANGED)) }
        })
        refresh(c, true)
    }

    private fun refresh(c: Player, rebuildQueue: Boolean) {
        val item = c.currentMediaItem
        val md = item?.mediaMetadata
        val dur = c.duration
        _player.update { old ->
            old.copy(
                connected = true,
                isPlaying = c.isPlaying,
                mediaId = item?.mediaId,
                title = md?.title?.toString().orEmpty(),
                artist = md?.artist?.toString().orEmpty(),
                album = md?.albumTitle?.toString().orEmpty(),
                durationMs = if (dur == C.TIME_UNSET) 0L else dur,
                shuffle = c.shuffleModeEnabled,
                repeat = c.repeatMode,
                speed = c.playbackParameters.speed,
                pitch = c.playbackParameters.pitch,
                index = c.currentMediaItemIndex,
                queue = if (rebuildQueue) List(c.mediaItemCount) { i ->
                    val m = c.getMediaItemAt(i)
                    QueueItem(m.mediaId, m.mediaMetadata.title?.toString().orEmpty(), m.mediaMetadata.artist?.toString().orEmpty())
                } else old.queue,
            )
        }
    }

    override fun onCleared() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onCleared()
    }

    // ------------------------------------------------------------ transport
    fun playSongs(list: List<SongEntity>, start: Int = 0, shuffle: Boolean? = null) {
        val c = controller ?: return
        if (list.isEmpty()) return
        val s = start.coerceIn(0, list.size - 1)
        val ordered = if (s > 0) list.drop(s) + list.take(s) else list
        val items = ordered.take(MAX_QUEUE).map { it.toMediaItem() }
        if (shuffle != null) c.shuffleModeEnabled = shuffle
        c.setMediaItems(items, 0, 0L)
        c.prepare()
        c.play()
    }

    fun shuffleAll() = playSongs(songs.value.shuffled(), 0, true)
    fun playNext(list: List<SongEntity>) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSongs(list) else c.addMediaItems(c.currentMediaItemIndex + 1, list.map { it.toMediaItem() })
    }
    fun enqueue(list: List<SongEntity>) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playSongs(list) else c.addMediaItems(list.map { it.toMediaItem() })
    }
    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else { if (it.playbackState == Player.STATE_IDLE) it.prepare(); it.play() } } }
    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms.coerceAtLeast(0L)) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun playQueueItem(i: Int) { controller?.let { it.seekToDefaultPosition(i); it.play() } }
    fun moveQueue(from: Int, to: Int) { controller?.let { if (to in 0 until it.mediaItemCount) it.moveMediaItem(from, to) } }
    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }
    fun clearQueue() { controller?.let { it.stop(); it.clearMediaItems() } }

    fun setSpeed(speed: Float, linked: Boolean, persist: Boolean = true) {
        val s = (Math.round(speed.coerceIn(0.5f, 2f) * 20) / 20f)
        controller?.playbackParameters = PlaybackParameters(s, if (linked) s else 1f)
        if (persist) viewModelScope.launch { prefs.setSpeed(s, linked) }
    }

    // ------------------------------------------------------------ library actions
    fun toggleFavorite(uris: List<String>, fav: Boolean) { viewModelScope.launch { repo.setFavorite(uris, fav) } }
    fun editMeta(uri: String, title: String, artist: String, album: String) {
        viewModelScope.launch { repo.editMeta(uri, title.ifBlank { "?" }, artist, album) }
    }
    fun startScan() { viewModelScope.launch { repo.scanAll(settings.value.folders) } }
    fun addFolder(uri: Uri) {
        runCatching { xyz.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        viewModelScope.launch { prefs.addFolder(uri.toString()); repo.scanAll(settings.value.folders + uri.toString()) }
    }
    fun removeFolder(uri: String) {
        viewModelScope.launch {
            prefs.removeFolder(uri)
            runCatching { xyz.contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            repo.scanAll(settings.value.folders - uri)
        }
    }
    fun addFiles(uris: List<Uri>) { viewModelScope.launch { repo.importFiles(uris) } }

    // ------------------------------------------------------------ playlists
    fun createPlaylist(name: String, uris: List<String> = emptyList()) { viewModelScope.launch { repo.createPlaylist(name.trim(), uris) } }
    fun renamePlaylist(id: Long, name: String) { viewModelScope.launch { repo.renamePlaylist(id, name.trim()) } }
    fun deletePlaylist(id: Long) { viewModelScope.launch { repo.deletePlaylist(id) } }
    fun addToPlaylist(id: Long, uris: List<String>) { viewModelScope.launch { repo.addToPlaylist(id, uris) } }
    fun movePlaylistItem(pl: PlaylistUi, from: Int, to: Int) {
        if (to !in pl.songs.indices) return
        val l = pl.songs.map { it.uri }.toMutableList()
        l.add(to, l.removeAt(from))
        viewModelScope.launch { repo.setPlaylistOrder(pl.id, l) }
    }
    fun removeFromPlaylist(pl: PlaylistUi, index: Int) {
        val l = pl.songs.map { it.uri }.toMutableList()
        if (index in l.indices) l.removeAt(index)
        viewModelScope.launch { repo.setPlaylistOrder(pl.id, l) }
    }

    // ------------------------------------------------------------ settings
    fun setTheme(v: Int) { viewModelScope.launch { prefs.setTheme(v) } }
    fun setAccent(v: Int) { viewModelScope.launch { prefs.setAccent(v) } }
    fun setGrid(v: Boolean) { viewModelScope.launch { prefs.setGrid(v) } }
    fun setLyricsSize(v: Int) { viewModelScope.launch { prefs.setLyricsSize(v) } }
    fun setLyricsOffset(v: Int) { viewModelScope.launch { prefs.setLyricsOffset(v) } }
    fun setReduceMotion(v: Boolean) { viewModelScope.launch { prefs.setReduceMotion(v) } }
    fun setCrossfade(ms: Int) { PlaybackRuntime.crossfadeMs = ms; viewModelScope.launch { prefs.setCrossfade(ms) } }

    // ------------------------------------------------------------ lyrics
    fun importLyrics(uri: Uri) {
        val id = _player.value.mediaId ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching {
                    xyz.contentResolver.openInputStream(uri)?.use { lyricsStore.save(id, it.bufferedReader().readText()) }
                }
            }
            lyricsRevision.update { it + 1 }
        }
    }
    fun removeLyrics() {
        val id = _player.value.mediaId ?: return
        lyricsStore.delete(id)
        lyricsRevision.update { it + 1 }
    }

    // ------------------------------------------------------------ EQ profiles
    fun saveEqProfile(name: String) {
        val d = AudioEngine.dsp.value
        val list = eqProfiles.value.filter { it.name != name } + EqProfile(name, d.preampDb, d.bandsDb)
        viewModelScope.launch { prefs.saveEqProfiles(list) }
        AudioEngine.update { it.copy(presetId = "custom:$name") }
    }
    fun deleteEqProfile(name: String) {
        viewModelScope.launch { prefs.saveEqProfiles(eqProfiles.value.filter { it.name != name }) }
        if (AudioEngine.dsp.value.presetId == "custom:$name") AudioEngine.update { it.copy(presetId = "custom") }
    }

    companion object { const val MAX_QUEUE = 1000 }
}
