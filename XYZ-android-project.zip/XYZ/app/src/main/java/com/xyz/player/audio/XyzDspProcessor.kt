package com.xyz.player.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * ExoPlayer audio processor that runs [DspCore] on the decoded PCM stream (16-bit or float).
 * It sits before ExoPlayer's own Sonic speed/pitch stage, so EQ/effects are applied at the original time base.
 */
class XyzDspProcessor(private val core: DspCore) : BaseAudioProcessor() {
    private var isFloat = false
    private var scratch = FloatArray(0)

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            throw UnhandledAudioFormatException(inputAudioFormat)
        }
        isFloat = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        core.configure(inputAudioFormat.sampleRate, inputAudioFormat.channelCount)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val channels = inputAudioFormat.channelCount
        val out = replaceOutputBuffer(size).order(ByteOrder.nativeOrder())
        val src = inputBuffer.duplicate().order(ByteOrder.nativeOrder())
        if (isFloat) {
            val n = size / 4
            if (scratch.size < n) scratch = FloatArray(n)
            src.asFloatBuffer().get(scratch, 0, n)
            core.process(scratch, n / channels)
            out.asFloatBuffer().put(scratch, 0, n)
        } else {
            val n = size / 2
            if (scratch.size < n) scratch = FloatArray(n)
            val sb = src.asShortBuffer()
            for (i in 0 until n) scratch[i] = sb.get(i) / 32768f
            core.process(scratch, n / channels)
            val ob = out.asShortBuffer()
            for (i in 0 until n) {
                val v = Math.round(scratch[i] * 32767f).coerceIn(-32768, 32767)
                ob.put(i, v.toShort())
            }
        }
        inputBuffer.position(inputBuffer.limit())
        out.position(size)
        out.flip()
    }

    override fun onFlush() { core.reset() }
}
