package com.xyz.player.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Rounded panel used for every grouped section (EQ, effects, settings). */
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(30.dp),
        color = cs.surfaceContainerLow,
        shadowElevation = 3.dp,
        border = BorderStroke(1.dp, cs.outlineVariant.copy(alpha = 0.7f)),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), modifier = modifier, style = MaterialTheme.typography.labelMedium,
        letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/** Slider with a large round white thumb and accent ring. */
@Composable
fun XyzSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    onValueChangeFinished: (() -> Unit)? = null,
    thumbSize: Dp = 28.dp,
) {
    val ring = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    val src = remember { MutableInteractionSource() }
    Slider(
        value = value, onValueChange = onValueChange, modifier = modifier, enabled = enabled,
        valueRange = valueRange, steps = steps, onValueChangeFinished = onValueChangeFinished, interactionSource = src,
        thumb = {
            Box(
                Modifier.size(thumbSize).shadow(6.dp, CircleShape)
                    .background(Color.White, CircleShape).border(thumbSize / 7, ring, CircleShape),
            )
        },
    )
}

/** Big circular toggle (BASS / HALL / SPATIAL style) with a glow when active. */
@Composable
fun CircleToggle(label: String, caption: String, active: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val reduce = LocalReduceMotion.current
    val spec = if (reduce) snap<Float>() else tween<Float>(300)
    val glow by animateFloatAsState(if (active) 1f else 0f, spec, label = "glow")
    val top by animateColorAsState(if (active) cs.primary else cs.surfaceContainerHighest, label = "top")
    val bottom by animateColorAsState(if (active) cs.tertiary.copy(alpha = 0.85f).let { androidx.compose.ui.graphics.lerp(cs.primary, it, 0.35f) } else cs.surfaceContainerHigh, label = "bottom")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(92.dp)
                .semantics(mergeDescendants = true) { contentDescription = label }
                .toggleable(value = active, role = Role.Switch, onValueChange = { onToggle() })
                .padding(4.dp),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(92.dp)) {
                drawCircle(cs.primary.copy(alpha = 0.16f * glow), radius = size.minDimension / 2)
            }
            Box(
                Modifier.size(80.dp).shadow(if (active) 14.dp else 4.dp, CircleShape, spotColor = cs.primary)
                    .clip(CircleShape).background(Brush.linearGradient(listOf(top, bottom)))
                    .border(1.5.dp, if (active) Color.White.copy(alpha = 0.5f) else cs.outlineVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp, color = if (active) cs.onPrimary else cs.onSurface, textAlign = TextAlign.Center)
            }
        }
        Text(caption.uppercase(), fontSize = 10.sp, letterSpacing = 1.5.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Rotary knob: drag up/right to increase, down/left to decrease. */
@Composable
fun Knob(
    value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit,
    label: String, valueText: String, enabled: Boolean = true, modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val onChangeS by rememberUpdatedState(onChange)
    val cur by rememberUpdatedState(value)
    val accent = if (enabled) cs.primary else cs.outline
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(116.dp)
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectDragGestures { change, drag ->
                        change.consume()
                        val span = range.endInclusive - range.start
                        onChangeS((cur + (drag.x - drag.y) / 360f * span).coerceIn(range.start, range.endInclusive))
                    }
                }
                .semantics {
                    contentDescription = label
                    stateDescription = valueText
                    progressBarRangeInfo = ProgressBarRangeInfo(value, range, 0)
                    setProgress { v -> onChangeS(v.coerceIn(range.start, range.endInclusive)); true }
                },
        ) {
            val stroke = 9.dp.toPx()
            val r = size.minDimension / 2
            val arcTopLeft = Offset(stroke / 2, stroke / 2)
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
            drawArc(cs.outlineVariant, 135f, 270f, false, arcTopLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (frac > 0.002f) drawArc(accent, 135f, 270f * frac, false, arcTopLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            val body = r - stroke - 6.dp.toPx()
            drawCircle(Color.Black.copy(alpha = 0.10f), body + 3.dp.toPx(), center.copy(y = center.y + 3.dp.toPx()))
            drawCircle(Brush.radialGradient(listOf(cs.surfaceContainerLowest, cs.surfaceContainerHighest), center, body), body, center)
            drawCircle(cs.outlineVariant, body, center, style = Stroke(1.dp.toPx()))
            val ang = (135f + 270f * frac) * PI.toFloat() / 180f
            val inner = body * 0.45f
            val outer = body * 0.86f
            drawLine(accent, Offset(center.x + cos(ang) * inner, center.y + sin(ang) * inner), Offset(center.x + cos(ang) * outer, center.y + sin(ang) * outer), 4.dp.toPx(), StrokeCap.Round)
        }
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, letterSpacing = 1.5.sp, color = cs.onSurfaceVariant)
        Text(valueText, style = MaterialTheme.typography.labelLarge, color = accent, fontWeight = FontWeight.SemiBold)
    }
}
