package com.xyz.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.xyz.player.R
import com.xyz.player.data.fromKey
import com.xyz.player.data.toKey

object Routes {
    const val HOME = "home"
    const val LIBRARY = "library"
    const val PLAYLISTS = "playlists"
    const val EFFECTS = "effects"
    const val SETTINGS = "settings"
    const val SEARCH = "search"
    const val OUTPUT = "output"
    const val LIST = "list/{type}/{key}"
    const val PLAYLIST = "playlist/{id}"
    fun list(type: String, key: String) = "list/$type/x${key.toKey()}"
    fun playlist(id: Long) = "playlist/$id"
}

private data class TabItem(val route: String, val labelRes: Int, val icon: ImageVector)

fun NavController.navigateTab(route: String) = navigate(route) {
    popUpTo(graph.findStartDestination().id) { saveState = true }
    launchSingleTop = true
    restoreState = true
}

@Composable
fun XyzRoot() {
    val vm: MainViewModel = viewModel()
    val settings by vm.settings.collectAsStateWithLifecycle()
    XyzTheme(settings) { AppShell(vm) }
}

@Composable
fun AppShell(vm: MainViewModel) {
    val nav = rememberNavController()
    val st by vm.player.collectAsStateWithLifecycle()
    var expanded by rememberSaveable { mutableStateOf(false) }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val snack = remember { SnackbarHostState() }
    val ctx = LocalContext.current

    LaunchedEffect(Unit) {
        vm.errors.collect { title -> snack.showSnackbar(ctx.getString(R.string.play_error, title.ifBlank { "?" })) }
    }

    val tabs = listOf(
        TabItem(Routes.HOME, R.string.nav_home, Icons.Rounded.Home),
        TabItem(Routes.LIBRARY, R.string.nav_library, Icons.Rounded.LibraryMusic),
        TabItem(Routes.PLAYLISTS, R.string.nav_playlists, Icons.Rounded.PlaylistPlay),
        TabItem(Routes.EFFECTS, R.string.nav_effects, Icons.Rounded.Tune),
        TabItem(Routes.SETTINGS, R.string.nav_settings, Icons.Rounded.Settings),
    )

    Box(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize()) {
            if (wide) {
                NavigationRail(containerColor = Color.Transparent) {
                    tabs.forEach { t ->
                        NavigationRailItem(
                            selected = route == t.route,
                            onClick = { nav.navigateTab(t.route) },
                            icon = { Icon(t.icon, null) },
                            label = { Text(stringResource(t.labelRes)) },
                            alwaysShowLabel = true,
                        )
                    }
                }
            }
            Scaffold(
                modifier = Modifier.weight(1f),
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snack) },
                bottomBar = {
                    if (st.mediaId != null || !wide) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                            shadowElevation = 16.dp,
                        ) {
                            Column(Modifier.padding(top = 8.dp)) {
                                if (st.mediaId != null) MiniPlayer(vm, onExpand = { expanded = true })
                                if (!wide) {
                                    NavigationBar(containerColor = Color.Transparent) {
                                        tabs.forEach { t ->
                                            NavigationBarItem(
                                                selected = route == t.route,
                                                onClick = { nav.navigateTab(t.route) },
                                                icon = { Icon(t.icon, null) },
                                                label = { Text(stringResource(t.labelRes), maxLines = 1) },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
            ) { pad ->
                NavHost(nav, Routes.HOME, Modifier.padding(pad)) {
                    composable(Routes.HOME) { HomeScreen(vm, nav) }
                    composable(Routes.LIBRARY) { LibraryScreen(vm, nav) }
                    composable(Routes.PLAYLISTS) { PlaylistsScreen(vm, nav) }
                    composable(Routes.EFFECTS) { EffectsScreen(vm, nav) }
                    composable(Routes.SETTINGS) { SettingsScreen(vm, nav) }
                    composable(Routes.SEARCH) { SearchScreen(vm, nav) }
                    composable(Routes.OUTPUT) { OutputScreen(nav) }
                    composable(
                        Routes.LIST,
                        arguments = listOf(navArgument("type") { type = NavType.StringType }, navArgument("key") { type = NavType.StringType }),
                    ) { e ->
                        ListDetailScreen(
                            vm, nav,
                            e.arguments?.getString("type").orEmpty(),
                            e.arguments?.getString("key").orEmpty().removePrefix("x").fromKey(),
                        )
                    }
                    composable(Routes.PLAYLIST, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                        PlaylistDetailScreen(vm, nav, e.arguments?.getLong("id") ?: -1L)
                    }
                }
            }
        }
        AnimatedVisibility(
            visible = expanded,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        ) {
            NowPlayingScreen(
                vm,
                onClose = { expanded = false },
                onOpenEffects = { expanded = false; nav.navigateTab(Routes.EFFECTS) },
                onOpenOutput = { expanded = false; nav.navigate(Routes.OUTPUT) },
            )
        }
    }
    BackHandler(enabled = expanded) { expanded = false }
}
