package com.xyz.player.audio

import android.media.AudioDeviceInfo
import android.os.Handler
import android.os.Looper
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Process-wide holder for the DSP chain; UI writes settings, the audio thread reads them. */
object AudioEngine {
    val core = DspCore()
    private val _dsp = MutableStateFlow(DspSettings())
    val dsp: StateFlow<DspSettings> = _dsp.asStateFlow()

    fun setDsp(s: DspSettings) { _dsp.value = s; core.settings = s }
    fun update(block: (DspSettings) -> DspSettings) = setDsp(block(_dsp.value))
}

data class TechInfo(
    val mediaId: String?,
    val mime: String?,
    val codecs: String?,
    val sampleRate: Int,
    val channels: Int,
    val bitrate: Int,
    val pcmBits: Int?,
)

/** State published by the playback service (same process) for the UI. */
object PlaybackRuntime {
    @Volatile var player: ExoPlayer? = null
    @Volatile var crossfadeMs: Int = 0
    val embeddedLyrics = MutableStateFlow<Pair<String, String>?>(null)
    val tech = MutableStateFlow<TechInfo?>(null)
    val replayGainDb = MutableStateFlow<Float?>(null)
    val errors = MutableSharedFlow<String>(extraBufferCapacity = 4)

    fun setPreferredDevice(d: AudioDeviceInfo?) { player?.setPreferredAudioDevice(d) }
}

object SleepTimer {
    data class State(val endAtMs: Long = 0L, val untilEndOfTrack: Boolean = false) {
        val active get() = endAtMs > 0L || untilEndOfTrack
    }

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()
    private val handler = Handler(Looper.getMainLooper())
    private val fire = Runnable {
        PlaybackRuntime.player?.pause()
        _state.value = State()
    }

    fun startMinutes(min: Int) {
        cancel()
        _state.value = State(endAtMs = System.currentTimeMillis() + min * 60_000L)
        handler.postDelayed(fire, min * 60_000L)
    }

    fun startEndOfTrack() {
        cancel()
        _state.value = State(untilEndOfTrack = true)
        PlaybackRuntime.player?.setPauseAtEndOfMediaItems(true)
    }

    fun cancel() {
        handler.removeCallbacks(fire)
        PlaybackRuntime.player?.setPauseAtEndOfMediaItems(false)
        _state.value = State()
    }

    /** Called by the service when playback paused itself at the end of an item. */
    fun onEndOfTrackPause() {
        if (_state.value.untilEndOfTrack) {
            PlaybackRuntime.player?.setPauseAtEndOfMediaItems(false)
            _state.value = State()
        }
    }
}
