package com.xyz.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xyz.player.R
import com.xyz.player.data.SongEntity

data class RowExtra(val labelRes: Int, val action: (Int) -> Unit)

/** Song list/grid with multi-select, context menus, and the standard actions. Reused by every list screen. */
@Composable
fun SongListContent(
    songs: List<SongEntity>,
    vm: MainViewModel,
    modifier: Modifier = Modifier,
    grid: Boolean = false,
    extras: List<RowExtra> = emptyList(),
    header: (@Composable () -> Unit)? = null,
    emptyTitle: Int = R.string.empty_songs_title,
    emptyBody: Int = R.string.empty_songs_body,
) {
    val st by vm.player.collectAsStateWithLifecycle()
    val selected = remember { mutableStateListOf<String>() }
    val selecting = selected.isNotEmpty()
    var playlistTarget by remember { mutableStateOf<List<String>?>(null) }
    var editTarget by remember { mutableStateOf<SongEntity?>(null) }
    BackHandler(selecting) { selected.clear() }

    fun toggle(uri: String) { if (uri in selected) selected.remove(uri) else selected.add(uri) }
    fun menuFor(i: Int, s: SongEntity): List<MenuAction> = buildList {
        add(MenuAction(R.string.play_next) { vm.playNext(listOf(s)) })
        add(MenuAction(R.string.add_to_queue) { vm.enqueue(listOf(s)) })
        add(MenuAction(R.string.add_to_playlist) { playlistTarget = listOf(s.uri) })
        add(MenuAction(if (s.favorite) R.string.remove_favorite else R.string.add_favorite) { vm.toggleFavorite(listOf(s.uri), !s.favorite) })
        add(MenuAction(R.string.edit_info) { editTarget = s })
        extras.forEach { e -> add(MenuAction(e.labelRes) { e.action(i) }) }
    }

    Column(modifier) {
        AnimatedVisibility(selecting) {
            val chosen = songs.filter { it.uri in selected }
            Surface(color = MaterialTheme.colorScheme.primaryContainer) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selected.clear() }) { Icon(Icons.Rounded.Close, stringResource(R.string.cancel)) }
                    Text(stringResource(R.string.n_selected, selected.size), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    IconButton(onClick = { selected.clear(); selected.addAll(songs.map { it.uri }.distinct()) }) { Icon(Icons.Rounded.SelectAll, stringResource(R.string.select_all)) }
                    IconButton(onClick = { vm.playSongs(chosen, 0); selected.clear() }) { Icon(Icons.Rounded.PlayArrow, stringResource(R.string.play)) }
                    IconButton(onClick = { vm.enqueue(chosen); selected.clear() }) { Icon(Icons.Rounded.QueueMusic, stringResource(R.string.add_to_queue)) }
                    IconButton(onClick = { playlistTarget = selected.toList() }) { Icon(Icons.Rounded.PlaylistAdd, stringResource(R.string.add_to_playlist)) }
                    IconButton(onClick = {
                        val allFav = chosen.all { it.favorite }
                        vm.toggleFavorite(chosen.map { it.uri }, !allFav); selected.clear()
                    }) { Icon(Icons.Rounded.Favorite, stringResource(R.string.add_favorite)) }
                }
            }
        }
        if (songs.isEmpty()) {
            header?.invoke()
            EmptyState(Icons.Rounded.MusicNote, stringResource(emptyTitle), stringResource(emptyBody))
        } else if (grid) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (header != null) item(span = { GridItemSpan(maxLineSpan) }) { header() }
                itemsIndexed(songs) { i, s ->
                    SongCard(
                        song = s, isCurrent = s.uri == st.mediaId, selected = s.uri in selected, selecting = selecting,
                        menu = menuFor(i, s),
                        onClick = { if (selecting) toggle(s.uri) else vm.playSongs(songs, i) },
                        onLongClick = { toggle(s.uri) },
                    )
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
                if (header != null) item { header() }
                itemsIndexed(songs) { i, s ->
                    SongRow(
                        song = s, isCurrent = s.uri == st.mediaId, isPlaying = st.isPlaying,
                        selected = s.uri in selected, selecting = selecting, menu = menuFor(i, s),
                        onClick = { if (selecting) toggle(s.uri) else vm.playSongs(songs, i) },
                        onLongClick = { toggle(s.uri) },
                    )
                }
            }
        }
    }
    playlistTarget?.let { uris -> PlaylistPickerDialog(vm, uris) { playlistTarget = null; selected.clear() } }
    editTarget?.let { s -> EditMetaDialog(s, vm) { editTarget = null } }
}
