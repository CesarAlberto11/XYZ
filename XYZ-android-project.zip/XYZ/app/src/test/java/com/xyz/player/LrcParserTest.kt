package com.xyz.player

import com.xyz.player.lyrics.LrcParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {
    @Test fun parsesSyncedLinesAndMultipleStamps() {
        val l = LrcParser.parse("[ti:Song]\n[00:12.50]Hello\n[00:05.00][00:20.00]Chorus\n")
        assertTrue(l.synced)
        assertEquals(3, l.lines.size)
        assertEquals(5000L, l.lines[0].timeMs)
        assertEquals("Chorus", l.lines[0].text)
        assertEquals(12500L, l.lines[1].timeMs)
        assertEquals(20000L, l.lines[2].timeMs)
    }

    @Test fun appliesOffsetTag() {
        val l = LrcParser.parse("[offset:+500]\n[00:10.00]Line")
        assertEquals(9500L, l.lines[0].timeMs)
    }

    @Test fun plainTextIsUnsynced() {
        val l = LrcParser.parse("First line\nSecond line")
        assertFalse(l.synced)
        assertEquals(2, l.lines.size)
    }

    @Test fun stripsWordLevelStamps() {
        val l = LrcParser.parse("[00:01.00]<00:01.00>Hel<00:01.40>lo")
        assertEquals("Hello", l.lines[0].text)
    }

    @Test fun indexAtFindsCurrentLine() {
        val l = LrcParser.parse("[00:05.00]A\n[00:10.00]B\n[00:15.00]C")
        assertEquals(-1, LrcParser.indexAt(l.lines, 1000))
        assertEquals(0, LrcParser.indexAt(l.lines, 5000))
        assertEquals(1, LrcParser.indexAt(l.lines, 12000))
        assertEquals(2, LrcParser.indexAt(l.lines, 999_999))
    }
}
