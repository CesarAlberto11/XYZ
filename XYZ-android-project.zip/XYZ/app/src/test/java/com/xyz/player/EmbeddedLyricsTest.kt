package com.xyz.player

import com.xyz.player.lyrics.EmbeddedLyrics
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.ByteArrayOutputStream

class EmbeddedLyricsTest {
    private fun be32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
    private fun le32(v: Int) = byteArrayOf(v.toByte(), (v ushr 8).toByte(), (v ushr 16).toByte(), (v ushr 24).toByte())
    private fun cat(vararg p: ByteArray): ByteArray { val o = ByteArrayOutputStream(); p.forEach { o.write(it) }; return o.toByteArray() }
    private fun id3Header() = byteArrayOf('I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte(), 3, 0, 0, 0, 0, 0, 0)
    private fun frame(id: String, data: ByteArray) = cat(id.toByteArray(), be32(data.size), byteArrayOf(0, 0), data)

    @Test fun readsUsltUtf8() {
        val data = cat(byteArrayOf(3), "eng".toByteArray(), byteArrayOf(0), "[00:01.00]Hola\n[00:02.00]Mundo".toByteArray())
        val text = EmbeddedLyrics.parseId3(id3Header(), cat(frame("TIT2", cat(byteArrayOf(3), "x".toByteArray())), frame("USLT", data)))
        assertEquals("[00:01.00]Hola\n[00:02.00]Mundo", text)
    }

    @Test fun convertsSyltToLrc() {
        val data = cat(
            byteArrayOf(0), "eng".toByteArray(), byteArrayOf(2, 1), byteArrayOf(0),
            "Hello".toByteArray(), byteArrayOf(0), be32(1000),
            "World".toByteArray(), byteArrayOf(0), be32(65_500),
        )
        assertEquals("[00:01.00]Hello\n[01:05.50]World", EmbeddedLyrics.parseId3(id3Header(), frame("SYLT", data)))
    }

    @Test fun noLyricsReturnsNull() {
        assertNull(EmbeddedLyrics.parseId3(id3Header(), frame("TIT2", cat(byteArrayOf(3), "x".toByteArray()))))
    }

    @Test fun readsM4aLyricsAtom() {
        fun box(type: ByteArray, payload: ByteArray) = cat(be32(8 + payload.size), type, payload)
        val text = "Linea uno\nLinea dos".toByteArray()
        val data = box("data".toByteArray(), cat(be32(1), be32(0), text))
        val lyr = box(byteArrayOf(0xA9.toByte(), 'l'.code.toByte(), 'y'.code.toByte(), 'r'.code.toByte()), data)
        val ilst = box("ilst".toByteArray(), lyr)
        val meta = box("meta".toByteArray(), cat(be32(0), ilst))
        val udta = box("udta".toByteArray(), meta)
        assertEquals("Linea uno\nLinea dos", EmbeddedLyrics.parseMp4Moov(udta))
    }

    @Test fun readsFlacVorbisLyrics() {
        val vendor = "xyz".toByteArray()
        val c1 = "TITLE=Song".toByteArray(); val c2 = "LYRICS=Hello flac".toByteArray()
        val block = cat(le32(vendor.size), vendor, le32(2), le32(c1.size), c1, le32(c2.size), c2)
        assertEquals("Hello flac", EmbeddedLyrics.parseVorbisComments(block))
    }
}
