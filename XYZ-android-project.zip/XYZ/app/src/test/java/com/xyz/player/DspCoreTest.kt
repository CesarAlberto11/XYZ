package com.xyz.player

import com.xyz.player.audio.DspCore
import com.xyz.player.audio.DspSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt
import org.junit.Test

class DspCoreTest {
    private val fs = 44100

    private fun sine(freq: Double, amp: Float, frames: Int): FloatArray {
        val b = FloatArray(frames * 2)
        for (i in 0 until frames) { val v = (amp * sin(2 * PI * freq * i / fs)).toFloat(); b[2 * i] = v; b[2 * i + 1] = v }
        return b
    }

    private fun rms(b: FloatArray, from: Int): Double {
        var s = 0.0; var n = 0
        for (i in from until b.size step 2) { s += b[i] * b[i]; n++ }
        return sqrt(s / n)
    }

    private fun core(s: DspSettings) = DspCore().also { it.configure(fs, 2); it.settings = s }

    @Test fun bypassLeavesSignalUntouched() {
        val src = sine(440.0, 0.5f, 4096)
        val buf = src.copyOf()
        core(DspSettings(bypassAll = true)).process(buf, 4096)
        for (i in buf.indices) assertEquals(src[i], buf[i], 0f)
    }

    @Test fun eqBoostsCenterFrequencyByConfiguredGain() {
        val gains = List(10) { if (it == 5) 12f else 0f } // 1 kHz band
        val buf = sine(1000.0, 0.05f, 16384)
        val before = rms(buf, 8192)
        core(DspSettings(eqEnabled = true, bandsDb = gains, limiter = false)).process(buf, 16384)
        val ratio = rms(buf, 8192) / before
        assertTrue("ratio=$ratio", ratio in 3.7..4.2) // +12 dB = 3.98x
    }

    @Test fun limiterKeepsPeaksInRange() {
        val buf = sine(200.0, 3.0f, 8192)
        core(DspSettings(limiter = true)).process(buf, 8192)
        assertTrue(buf.all { abs(it) <= 1.0f })
    }

    @Test fun balanceFullRightSilencesLeft() {
        val buf = sine(300.0, 0.4f, 2048)
        core(DspSettings(balance = 1f, limiter = false)).process(buf, 2048)
        for (i in 0 until 2048) assertEquals(0f, buf[2 * i], 1e-6f)
        assertTrue(abs(buf[2 * 100 + 1]) > 0f || abs(buf[2 * 101 + 1]) > 0f)
    }

    @Test fun hallReverbProducesTailAfterImpulse() {
        val frames = 20000
        val buf = FloatArray(frames * 2); buf[0] = 0.8f; buf[1] = 0.8f
        core(DspSettings(hallEnabled = true, hallProfile = 1, limiter = false)).process(buf, frames)
        var tail = 0.0
        for (i in 10000 until frames) tail += abs(buf[2 * i])
        assertTrue("tail=$tail", tail > 0.01)
    }

    @Test fun fftFindsSinePeakBin() {
        val n = DspCore.FFT_N
        val re = FloatArray(n) { sin(2 * PI * 64 * it / n).toFloat() }
        val im = FloatArray(n)
        DspCore.fft(re, im)
        var best = 1; var bestV = 0f
        for (k in 1 until n / 2) { val m = re[k] * re[k] + im[k] * im[k]; if (m > bestV) { bestV = m; best = k } }
        assertEquals(64, best)
    }
}
